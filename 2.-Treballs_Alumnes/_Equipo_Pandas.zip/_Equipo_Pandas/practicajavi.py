#!/usr/bin/env python
# coding: utf-8

# In[ ]:


PRACTICA DEFINITIVA


# In[1]:


# -*- coding: utf-8 -*-
from tkinter import * 
import tkinter as tk# Carga módulo tk (widgets estándar)
import plotly.graph_objects as go
 
    
class Application(Frame):
    def __init__(self, window):
        super().__init__(window)
        self.win = window
        self.dimension_pantalla ()
        self.pedir_menu ()
    def dimension_pantalla (self):
        self.win.title("Estadistica Tiempo")
        self.win.geometry('400x400')
        self.win.minsize(width=300, height=400)
        self.win.maxsize(width=300, height=400)
    def pedir_menu (self) :

            menubar = Menu(self.win)
            self.win.config(menu=menubar)
                   
                                 
            javierImenu = Menu(menubar, tearoff=0)
            javierImenu.add_command(label="Comparativo Barras 1",command=self.javi_opcion1)
            javierImenu.add_command(label="Comparativo Barras 2",command=self.javi_opcion2)
            javierImenu.add_command(label="Comparativo Plot",command=self.javi_opcion3)
            
            menubar.add_cascade(label="Elegir Grafico", menu=javierImenu)
    
    
    def javi_opcion1(self) :
        import plotly.graph_objects as go
           
        Paises=['Spain', 'Greece', 'Denmark', 'Netherland', 'Austria','Britain', 'France', 'Germany','Italy','Portugal']

        fig = go.Figure(data=[
            go.Bar(name='Lluvia', x=Paises, y=[20, 14, 23, 54, 56,67,34, 56, 67, 23]),
            go.Bar(name='Viento', x=Paises, y=[12, 18, 29, 45, 56, 67, 78, 32, 45, 76])])

        # Change the bar mode
        fig.update_layout(barmode='group') # me indica el tipo de barra que tengo que hacer servir, son barras separadas
        fig.show()
        fig.write_html("javi_opcion1.html")
               
    def javi_opcion2(self) :  
        import plotly.graph_objects as go

        zona = ['Spain', 'Greece', 'Denmark', 'Netherland', 'Austria','Britain', 'France', 'Germany','Italy','Portugal']
        lluvia = [39.57, 28.11, 3, 1.51, 22.22, 5.47, 0.11, 13,15,10]
        viento = [41.9, 14.89, 6.22, 1.85, 30.23, 4.78, 0.12, 0.15,12,10]
        total = [round((x + y/2), 2) for x, y in zip(lluvia, viento)] # zip coger dos listas y xa cada elemento te devuelve uno de cada lista

        print(lluvia)
        print(viento)
        print(total)

        fig = go.Figure(data=[
            go.Bar(name='lluvia', x=zona, y=lluvia, marker_color="#cc33ff"),
            go.Bar(name='viento', x=zona, y=viento,marker_color="#99ff66"),
            go.Bar(name="total", x=zona, y=total,marker_color="#0033cc")])

         # Change the bar mode
        fig.update_layout(barmode='group') 
        fig.show()
        fig.write_html("javi_opcion2.html")
        
    def javi_opcion3(self) : 
        import plotly.graph_objects as go
        import numpy as np

        x_data = ['Spain', 'Greece', 'Denmark', 'Netherland', 'Austria','Britain', 'France', 'Germany','Italy','Portugal']

        N = 50
    #cambiar valores random por valores excel
        y0 = (10 * np.random.randn(N) + 30).astype(np.int)
        y1 = (13 * np.random.randn(N) + 38).astype(np.int)
        y2 = (11 * np.random.randn(N) + 33).astype(np.int)
        y3 = (9 * np.random.randn(N) + 36).astype(np.int)
        y4 = (15 * np.random.randn(N) + 31).astype(np.int)
        y5 = (12 * np.random.randn(N) + 40).astype(np.int)
        y6 = (13 * np.random.randn(N) + 38).astype(np.int)
        y7 = (11 * np.random.randn(N) + 33).astype(np.int)
        y8 = (9 * np.random.randn(N) + 36).astype(np.int)
        y9 = (15 * np.random.randn(N) + 31).astype(np.int)
        y10 = (12 *np.random.randn(N) + 40).astype(np.int)

        y_data = [y0, y1, y2, y3, y4, y5, y6 ,y7 ,y8, y9 ,y10]

        colors = ['rgba(93, 164, 214, 0.5)', 'rgba(255, 144, 14, 0.5)', 'rgba(44, 160, 101, 0.5)',
                  'rgba(255, 65, 54, 0.5)', 'rgba(207, 114, 255, 0.5)', 'rgba(93, 200, 0, 0.5)','rgba(258, 148, 0, 0.5)',
                 'rgba(185, 80, 0, 0.5)','rgba(207, 66, 0, 0.5)','rgba(10, 10, 0, 0.5)','rgba(380, 46, 0, 0.5)']

        fig = go.Figure()
        
        for xd, yd, cls in zip(x_data, y_data, colors):
                fig.add_trace(go.Box(
                    y=yd,
                    name=xd,
                    boxpoints='all',
                    jitter=0.5,
                    whiskerwidth=0.2,
                    fillcolor=cls,
                    marker_size=2,
                    line_width=1)
                )

        fig.update_layout(
            title='Datos estadisticos del tiempo en una ciudad',
            yaxis=dict(
                autorange=True,
                showgrid=True,
                zeroline=True,
                dtick=5,
                gridcolor='rgb(255, 255, 255)',
                gridwidth=1,
                zerolinecolor='rgb(255, 255, 255)',
                zerolinewidth=2,
        ),
        margin=dict(
            l=40,
            r=30,
            b=80,
            t=100,
        ),
        paper_bgcolor='rgb(243, 243, 243)',
        plot_bgcolor='rgb(243, 243, 243)',
        showlegend=False
        )

        fig.show()
        fig.write_html("javi_opcion3.html")
        
       
         
window = tk.Tk()
app = Application(window)
app.mainloop()


# In[ ]:





# In[ ]:




