# -*- coding: utf-8 -*-
"""
Created on Tue Jul 13 13:31:23 2021

@author: mati
"""

import sqlite3

def abre_bd_formulari_joc():
    """ abre la conexion con la base de datos """
    
    db_name = "dat\\dades_joc.db"
    conexion = None
    
    try :
        conexion = sqlite3.connect(db_name)
    except Exception as e:
        print("Error en la base de datos: ", e) 
    return (conexion)
 
    

def crea_tabla():
    """ si no existe, crea la tabla de formularios"""

    conexion = abre_bd_formulari_joc()
    cursor = conexion.cursor()
    
    # Ahora crearemos una tabla de usuarios con nombres, edades y emails
    sql = "CREATE TABLE IF NOT EXISTS formulari_joc (nom VARCHAR(50), " 
    sql += "edad INT,res1 VARCHAR(50),res2 VARCHAR(50),  "
    sql += "res3 VARCHAR(50), res4 VARCHAR(100))"
    cursor.execute(sql)
     
   
    # Guardamos los cambios haciendo un commit
    conexion.commit()
    conexion.close()
    

    
def guardar_form(formulari):
 
    
    conexion = abre_bd_formulari_joc()
    cursor = conexion.cursor()
    
    str_sql = "INSERT INTO formulari_joc(nom, edad,res1, res2, res3,"\
              "  res4) VALUES (?,?,?,?,?,?);"
    #print(str_sql, formulari)
    cursor.execute (str_sql, formulari)

    # Guardamos los cambios haciendo un commit
    conexion.commit()
    conexion.close()

def consulta_forms() :
  
    
    conexion = abre_bd_formulari_joc()
    cursor = conexion.cursor()

    # Recuperamos los registros de la tabla de usuarios
    cursor.execute("SELECT * FROM formulari_joc")
    
    # Recorremos todos los registros con fetchall
    # y los volcamos en una lista de usuarios
    listado = cursor.fetchall()
    conexion.close()
    return (listado)
    
if __name__ == '__main__':

    crea_tabla()

  