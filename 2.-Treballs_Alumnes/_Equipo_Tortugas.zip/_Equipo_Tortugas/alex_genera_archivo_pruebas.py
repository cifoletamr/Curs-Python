# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

#--------------------------Inicio

#Creación de datos aleatorios para trabajar.
from io import open
import random as r
    
#------------------------------------------------- Definiciones

# Las variables del archivo de pruebas se aleatorizan de las listas:
#edad= random.randint(10, 100)
nombres=["Alex","Anna","Beatriz","Berto","Carlos", "Cristina","Diego","Diana"]
animales = ["Tortuga", "Perro", "Gato","Perro", "Gato"
            ,"Perro","Perro","Perro","Perro","Perro","Perro","Gato"
            ,"Gato","Perro","Perro","Perro"]
colores = ["Azul","Rojo","Verde","Azul","Azul","Verde"]
comidas=["Verdura", "Carne", "Pescado","Carne","Carne"]
titulos=["Tortuga", "Perro", "Gato","Azul","Rojo","Verde","Verdura", "Carne", "Pescado"]

#------------------------------------------------- Proceso principal

#------------------------------- 1. Abre archivo
fich = open("dat\pruebas_random_tortugas.csv","w")
#------------------------------- 2. Graba cabecera
linea= "Nombre;Edad;Animal;Color;Comida;Titulo\n"
fich.write(linea)
#sep = ";"????
#------------------------------- 3. Genera las lineas de datos
for i in range (1, 1000) :

    #------------------------------- Nombre; 
    linea = "{};".format(nombres[r.randint(0,len(nombres)-1)])  

    #------------------------------- edad;
    linea += '{};'.format(r.randint(10,100)) 
                                        
    #------------------------------- animal; color; comida; título;
    linea += '"{}";{};"{}";{}\n'.format(animales[r.randint(0,len(animales)-1)], 
                                       colores[r.randint(0,len(colores)-1)], 
                                       comidas[r.randint(0,len(comidas)-1)],
                                       titulos[r.randint(0,len(titulos)-1)])
    
    fich.write(linea)
#------------------------------- 4. Cierra el archivo
fich.close()