# -*- coding: utf-8 -*-
"""
Created on Tue Jul 13 12:21:53 2021

@author: Josep
"""

#-----------------------------------------IMPORTEM LES LLIBRERIES

from tkinter import *
from collections import Counter, OrderedDict

#-----------------------------------------DEFINICIÓ FUNCIONS

def num_paraules(llista = None):
    global r
    if llista == None: llista = lineas[0]
    r.set(len(llista))
    return(len(llista))

def llarga_paraula(llista = None):
    global r
    if llista == None: llista = lineas[0]
    max_len = -1
    for p_len in llista:
        if len(p_len) > max_len:
            max_len = len(p_len)
            p_longest = p_len
    r.set(p_longest)
    return (p_longest)

def curta_paraula(llista = None):
    global r
    p_shortest = ""
    if llista == None: llista = lineas[0]
    min_len = 100
    for p_len in llista:
        if len(p_len) < min_len:
            min_len = len(p_len)
            p_shortest = p_len
    r.set(p_shortest)
    return(p_shortest)

def comptador_paraula(llista = None):
    
    global r, t
    
    if llista == None: llista = lineas[0]
    #llista = llista.replace("\n", "")
    print("LLISTA COMPTADOR", llista)
    repe = Counter(llista)
    print("repe", repe)
    repe2 = OrderedDict(repe)
    print("repe2", repe2)
    tmp=""
    for key, value in repe2.items() :
        tmp = tmp + key + "," + str(value) + "\n"
    t.insert(1.0, tmp)
    print("TMP", tmp)
    return(tmp)

#-----------------------------------------CONFIGURACIÓ PANTALLA 1

def main():
        
    global r, t
    
    root = Tk()
    root.config(bd=15)
    
    r = StringVar()
    
    Button(root, text="Número paraules", command=num_paraules).pack()
    Button(root, text="Paraula més llarga", command=llarga_paraula).pack()
    Button(root, text="Paraula més curta", command=curta_paraula).pack()
    Button(root, text="Comptador de paraules", command=comptador_paraula).pack()
    
    Label(root, text="Resultado").pack(expand=True)
    Entry(root, textvariable=r, state="disabled").pack(expand=True)
    
    t = Text(root, height=10)
    t.pack(expand=True)
    
    #-----------------------------------------CONFIGURACIÓ .CSV LECTURA I SORTIDA
    
    f = open('dades_joc.csv', 'r')
    
    f2 = open("analisi_dades_joc.csv","w")
    f2.write ( f"num_p; p_llarga; p_curta; comt_p\n")
        
    lineas = f.readlines()
    
    for l in lineas :
        paraules = l.split(",")
        n1 = num_paraules(paraules)
        n2 = llarga_paraula(paraules)
        n3 = curta_paraula(paraules)
        n4 = comptador_paraula(paraules)
        
        f2.write ( f"{n1}; {n2}; {n3}; ''" + "\n")
        for p in n4 :
            f2.write ( f"''; ''; ''; '{p}'")
    
    #-----------------------------------------COMPROVACIÓ DADES A LA CONSOLA
    
    print("LINEAS:", lineas, sep='\n')
    print("PARAULES:", paraules, sep='\n')
    
    #-----------------------------------------TANCAMENT APLICACIÓ
    
    root.mainloop()


if __name__ == "__main__":
    # execute only if run as a script
    r =""    
    t ="" 
    main()