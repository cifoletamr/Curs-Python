# -*- coding: utf-8 -*-
"""
Created on Mon Jul 12 11:59:35 2021

@author: mati
"""
import tkinter as tk
from tkinter import Frame,Menu
import SofiaM_2 as sm
import alex as al
import JavierM as jm
import JuegoAnimal as an



class Application(Frame):
    def __init__(self, window):
        super().__init__(window)
        self.win = window
        self.dimension_pantalla ()
        self.pedir_menu ()
        
    def dimension_pantalla (self):
        self.win.title("Menú de las Tortugas")
        self.win.geometry('400x400')
        self.win.minsize(width=300, height=400)
        self.win.maxsize(width=300, height=400)

    def pedir_menu (self) :
       
        menubar = Menu(self.win)
        
        self.win.config(menu=menubar)
        
        josepmenu = Menu(menubar, tearoff=0)
        josepmenu.add_command(label='Josep opcion 1',
        command=self.josep_opcion1)

        sofiamenu = Menu(menubar, tearoff=0)
        sofiamenu.add_command(label='Sofia opcion 1',
        command=self.sofia_opcion1)
        
        alexmenu = Menu(menubar, tearoff=0)
        alexmenu.add_command(label='Alex opcion 1', command=self.alex_opcion1)
        
        annamenu = Menu(menubar, tearoff=0)
        annamenu.add_command(label='Anna opcion 1', command=self.anna_opcion1)
        
        polmenu = Menu(menubar, tearoff=0)
        polmenu.add_command(label='Pol opcion 1', command=self.pol_opcion1)
        
        javierm_menu = Menu(menubar, tearoff=0)
        polmenu.add_command(label='Javier M opcion 1', command=self.JavierM_opcion1)
               
        
        menubar.add_cascade(label="Josep", menu=josepmenu)
        menubar.add_cascade(label="Sofia", menu=sofiamenu)
        menubar.add_cascade(label="Alex", menu=alexmenu)
        menubar.add_cascade(label="Anna", menu=annamenu)
        menubar.add_cascade(label="Pol", menu=polmenu) 
        menubar.add_cascade(label="Javier M", menu=javierm_menu)
        javierm_menu.add_command(label="Estadísticas de Animales", command=self.animales)
        javierm_menu.add_command(label="Estadísticas de Colores", command=self.colores)
        javierm_menu.add_command(label="Estadísticas de Comidas", command=self.comidas)
        javierm_menu.add_command(label="Estadísticas de Palabras", command=self.descripcion_palabras)
                    
    def josep_opcion1 (self) :
        pass
        
    def sofia_opcion1 (self) :    
        window = tk.Tk()
        app = sm.Application(window)
        app.mainloop()        
  
    def alex_opcion1 (self) :
        window = tk.Tk()
        app = al.Application(window)
        app.mainloop() 
    
    def anna_opcion1 (self) :
        pass

    def pol_opcion1 (self) :
        pass
    
    def javi_opcion1 (self) :
        window = tk.Tk()
        app = jm.Application(window)
        app.mainloop()

#------------------------ Main program
window = tk.Tk()
app1 = Application(window)
app1.mainloop()



