# -*- coding: utf-8 -*-
"""
Created on Tue Jul 13 13:00:42 2021

@author: Alex Gordillo Soler
"""
#Uso de pandas para graficar datos de preferencias.

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt

#------------------------Definición de funciones
def genera_graf(labels,df):
    
    data=[]
    
    for f in range(len(df.index)):
        data.append(df.iloc[f,:])
        
    columns = labels
    rows = df.index.values
        
    values = np.arange(0, 1.1, 0.1)
        
    # Get some pastel shades for the colors
    colors = plt.cm.BuPu(np.linspace(0.15, 0.65, len(rows)))
    n_rows = len(data)
    
    index = np.arange(len(columns))
    bar_width = 0.5
    
    # Initialize the vertical-offset for the stacked bar chart.
    y_offset = np.zeros(len(columns))
    
    # Plot bars and create text labels for the table
    cell_text = []
    for row in range(n_rows):
        plt.bar(index, data[row], bar_width, bottom=y_offset, color=colors[row])
        y_offset = y_offset + data[row]
        cell_text.append(['%1.2f' % x for x in data[row]])
    
    # Reverse colors and text labels to display the last value at the top.
    colors = colors[::]
    
    
    # Add a table at the bottom of the axes
    the_table = plt.table(cellText=cell_text,
                          rowLabels=rows,
                          rowColours=colors,
                          colLabels=columns,
                          loc='bottom')
    
    # Ajuste del marco del cuadro del gráfico:
    plt.subplots_adjust(left=0, bottom=0)
        
    plt.ylabel("Proporción de respuestas")
    plt.yticks(values, ['%1.1f' % val for val in values])
    plt.xticks([])
    plt.title('Preferencia de animal según el rango de edad')
    
    return plt.show()

#-----------------------------------Inicio


nom_archivo="dat\dades_joc.csv"#Archivo real
nom_archivo="dat\pruebas_random_tortugas.csv" #Archivo de pruebas

dfbase = pd.read_csv(nom_archivo, sep=";")

print ("shape: ", dfbase.shape)
print ("columns: ", dfbase.columns)
print ("index: ", dfbase.index)

#Index(['Nombre', 'Edad', 'Animal', 'Color', 'Comida', 'Titulo']

df=dfbase

nnombres=df.value_counts('Nombre')
nedades=df.value_counts('Edad')
nanimales=df.value_counts('Animal')
ncolores=df.value_counts('Color')
ncomida=df.value_counts('Comida')
ntitulos=df.value_counts('Titulo')
print(nnombres,
      nedades,
      nanimales,
      ncolores,
      ncomida,
      ntitulos)

#pd.pivot_table(df, values="D", index=["A", "B"], columns=["C"])

#Queremos graficar las preferencias en función de la edad.
#Crear los rangos de edad <20, 21 a 40, 41 a 60, 61 a 80, 80+.
#Incoporamos una variable al frame con las categorias edad (cedad)
edades=[]
for e in df["Edad"]:
    if e <= 20:
        edades.append("[-,20]")
    elif e<=40:
        edades.append("[21,40]")
    elif e<=60:
        edades.append("[41,60]")
    elif e<=80:
        edades.append("[61,80]")
    else:
        edades.append("[81,+)")

df.insert(2, "Edades1", edades, True) 

#Otra manera de categorizar si la variable a categorizar es de valores (cuidado si hay edad==0).

labels = ["[{0},{1}]".format( i+1 , i + 20) for i in range(0, df["Edad"].max(), 20)]

print(labels)
df["Edades2"] = pd.cut(df.Edad, range(1, df["Edad"].max()+2, 20), right=False, labels=labels)


df["Edades1"]=df["Edades1"].astype("category")
df["Edades2"]=df["Edades2"].astype("category")

nedades1=df.value_counts('Edades1')
nedades2=df.value_counts('Edades2')
print(nedades1)
print(nedades2)

print ("shape: ", df.shape)
print ("columns: ", df.columns)
print ("index: ", df.index)
print(df.head(10))

#Respuestas de preferencias de animales, colores y comida por cada rango de edad.
#Creamos la tabla de datos.

t_ae = pd.crosstab(df["Animal"], df["Edades1"], normalize="columns")
print(t_ae)
t_ce = pd.crosstab(df["Color"], df["Edades1"], normalize="columns")
print(t_ce)
t_coe = pd.crosstab(df["Comida"], df["Edades1"], normalize="columns")
print(t_coe)

graf_ae=genera_graf(labels,t_ae)
graf_ce=genera_graf(labels,t_ce)
graf_coe=genera_graf(labels,t_coe)





