# -*- coding: utf-8 -*-
"""
Created on Mon Jul 12 13:13:47 2021

@autor: Anna Nicolas Fernandez
"""

import os
import pygame
import random
import csv
class Jugador(object):
    
    def __init__(self,muros,screen,imagen,x,y):
        self.x=x
        self.y=y
        self.rect = screen.blit(imagen,(x,y))
        self.muros = muros

    def mover(self, dx, dy):
        
        # Movemos el axis de la funcion.
        if dx != 0:
            self.mover_una_axis(dx, 0)
        if dy != 0:
            self.mover_una_axis(0, dy)
    
    def mover_una_axis(self, dx, dy):
        
        # Movemos la figura
        self.rect.x += dx
        self.rect.y += dy
        for muro in self.muros:
            if self.rect.colliderect(muro.rect):
                if dx > 0: # Moving right; Hit the left side of the wall
                    self.rect.right = muro.rect.left
                if dx < 0: # Moving left; Hit the right side of the wall
                    self.rect.left = muro.rect.right
                if dy > 0: # Moving down; Hit the top side of the wall
                    self.rect.bottom = muro.rect.top
                if dy < 0: # Moving up; Hit the bottom side of the wall
                    self.rect.top = muro.rect.bottom
    def dibuja_y_mueve (self,screen,imagen):             
        #Dibujamos la imagen del jugador
        self.rect=screen.blit(imagen, (self.rect.x,self.rect.y))  
    def puntuacion(self,screen,puntuacion):
        #Mostramos la puntuación
        font = pygame.font.SysFont(None, 25)
        text = font.render("Recogidos: "+str(puntuacion), True, (0,0,0))
        screen.blit(text,(40,0))
class Muro(object):
    
    def __init__(self,pos,muros):
        muros.append(self)
        self.rect = pygame.Rect(pos[0], pos[1], 36, 40)
class Bala(object):
    def __init__(self,screen,imagen,x=0,y=0):
        self.x=random.randint(40,660)
        self.y=y
        self.rect=screen.blit(imagen,(self.x,self.y))
        self.speed=5
    def dibuja_y_cae(self,screen,imagen):
        #Dibujamos y hacemos que la bala caiga
        self.rect=screen.blit(imagen,(self.x,self.y))
        self.y+=self.speed
        if self.y > 540:
            self.y=0
            self.x=random.randint(40,660)
            self.speed+=0.2
class Comida(object):
    def __init__(self,screen,imagen,x=0,y=0):
        self.x=random.randint(40,660)
        self.y=y
        self.rect=screen.blit(imagen,(self.x,self.y))
        self.speed=5
    def dibuja_y_cae(self,screen,imagen):
        #Dibujamos la imagen de la comida y hacemos que caiga
        self.rect=screen.blit(imagen,(self.x,self.y))
        self.y+=self.speed
        if self.y > 540:
            self.y=0
            self.x=random.randint(40,660)
    def desaparecer(self):
        #Si el jugador a conseguido coger la comida
        self.y=-5
        self.x=random.randint(40,680)

def main():        
    os.environ["SDL_VIDEO_CENTERED"] = "1"
    pygame.init()
    display_width=720
    display_height=580
    screen = pygame.display.set_mode((display_width, display_height))
    with open("dades_joc.csv", "r") as file:
        for line in file:
            pass
    lineas=line
    lineas=lineas.split(";")
    pygame.display.set_caption(lineas[5])
    clock = pygame.time.Clock()
    imagen=pygame.image.load(".\\img\\"+lineas[2].lower()+".png")
    muros=[]
    if (lineas[3]=="Verde"):
        color="green"
    if (lineas[3]=="Azul"):
        color="blue"
    if (lineas[3]=="Rojo"):
        color="red"
    level = [
    "W                  W",
    "W                  W",
    "W                  W",
    "W                  W",
    "W                  W",
    "W                  W",
    "W                  W",
    "W                  W",
    "W                  W",
    "W                  W",
    "W                  W",
    "W                  W",
    "W                  W",
    "W                  W",
    "WWWWWWWWWWWWWWWWWWWW",
    ]
    x = y = 0
    for row in level:
        for col in row:
            if col == "W":
                Muro((x, y),muros)
            x += 36
        y += 40
        x = 0
    puntuacion=0
    x=display_width * 0.45
    y=display_height * 0.8
    player = Jugador(muros,screen,imagen,x,y)
    bad_image=pygame.image.load(".\\img\\"+"bala.png")
    enemigo=Bala(screen,bad_image)
    enemigo2=Bala(screen,bad_image,y=-50)
    running = True
    imgcom=pygame.image.load(".\\img\\"+lineas[4].lower()+".png")
    menjar=Comida(screen,imgcom)
    while running:
        clock.tick(60)
    #-------------------------------------------------Bucle Eventos
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                running = False
            if e.type == pygame.KEYDOWN and e.key == pygame.K_ESCAPE:
                running = False
        key = pygame.key.get_pressed()
        if key[pygame.K_LEFT]:
            player.mover(-5, 0)
        if key[pygame.K_RIGHT]:
            player.mover(5, 0)
        if key[pygame.K_UP]:
            player.mover(0, -5)
        if key[pygame.K_DOWN]:
            player.mover(0, 5) 
        if player.rect.colliderect(enemigo) or player.rect.colliderect(enemigo2):
            print("You lose!")
            print("Your score is",puntuacion,"!")
            running=False
        if player.rect.colliderect(menjar):
            puntuacion+=1
            menjar.desaparecer()
    #--------------------------------------------------Fin bucle Eventos
        screen.fill(color)
        for muro in muros:
            pygame.draw.rect(screen, (0, 0, 0), muro.rect)
        player.dibuja_y_mueve(screen,imagen)
        menjar.dibuja_y_cae(screen, imgcom)
        enemigo.dibuja_y_cae(screen,bad_image)
        enemigo2.dibuja_y_cae(screen, bad_image)
        
        player.puntuacion(screen,puntuacion)
        pygame.display.update()
    pygame.quit()
    with open('FinalScore.csv', mode='a') as file:
        writer = csv.writer(file, delimiter=',', quotechar='"', quoting=csv.QUOTE_MINIMAL)
        writer.writerow([lineas[5],lineas[2],lineas[3],lineas[4],puntuacion])
    
if __name__ == "__main__":
    # execute only if run as a script
    main()