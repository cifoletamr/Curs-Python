# -*- coding: utf-8 -*-
"""
Created on Mon Jul 12 11:57:33 2021

@author: mati
"""

from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg, NavigationToolbar2Tk
from matplotlib.figure import Figure
import matplotlib as plt
import numpy as np
import tkinter
import tkinter as tk
from tkinter import *

class Application(Frame):
    def __init__(self, window):
        super().__init__(window)
        self.win = window
        self.dimension_pantalla()
        self.pedir_menu()

    def dimension_pantalla(self):
        self.win.title("Aplicación Tortugas")
        self.win.geometry('400x400')
        self.win.minsize(width=300, height=400)
        self.win.maxsize(width=300, height=400)

    def pedir_menu(self):
        menubar = Menu(self.win)
        self.win.config(menu=menubar)
        javierm_menu = Menu(menubar)
        javierm_menu = Menu(menubar, tearoff=0)
        javierm_menu.add_command(label="Estadísticas de Animales", command=self.animales)
        javierm_menu.add_command(label="Estadísticas de Colores", command=self.colores)
        javierm_menu.add_command(label="Estadísticas de Comidas", command=self.comidas)
        javierm_menu.add_command(label="Estadísticas de Palabras", command=self.descripcion_palabras)
        menubar.add_cascade(label="Javier Márquez", menu=javierm_menu)

    def animales(self):
        import pandas as pd
        import matplotlib.pyplot as plt
               
        df = pd.read_csv("animales.csv", sep=",")
        labels = df['animales'].unique()
        sizes = df.value_counts('animales')
        fig, ax = plt.subplots()
        ax.pie(sizes, labels = labels, autopct='%1.1f%%', shadow=True, startangle=90)
        plt.show()

        canvas = FigureCanvasTkAgg(fig, master=window)
        canvas.draw()
        canvas.get_tk_widget().pack(side=tkinter.TOP, fill=tkinter.BOTH, expand=1)
        toolbar = NavigationToolbar2Tk(canvas, window)
        toolbar.update()
        canvas.get_tk_widget().pack(side=tkinter.TOP, fill=tkinter.BOTH, expand=1)

    def colores(self):
        import pandas as pd
        import matplotlib.pyplot as plt

        df = pd.read_csv("animales.csv", sep=",")
        labels = df['colores'].unique()
        sizes = df.value_counts('colores')   
        fig, ax = plt.subplots()
        ax.pie(sizes, labels=labels, autopct='%1.1f%%', shadow=True, startangle=90)
        plt.show()

        canvas = FigureCanvasTkAgg(fig, master=window)
        canvas.draw()
        canvas.get_tk_widget().pack(side=tkinter.TOP, fill=tkinter.BOTH, expand=1)
        toolbar = NavigationToolbar2Tk(canvas, window)
        toolbar.update()
        canvas.get_tk_widget().pack(side=tkinter.TOP, fill=tkinter.BOTH, expand=1)

    def comidas(self):
        import pandas as pd
        import matplotlib.pyplot as plt

        df = pd.read_csv("animales.csv", sep=",")
        labels = df['comidas'].unique()
        sizes = df.value_counts('comidas')    
        fig, ax = plt.subplots()
        ax.pie(sizes, labels=labels, autopct='%1.1f%%', shadow=True, startangle=90)
        plt.show()

        canvas = FigureCanvasTkAgg(fig, master=window)
        canvas.draw()
        canvas.get_tk_widget().pack(side=tkinter.TOP, fill=tkinter.BOTH, expand=1)
        toolbar = NavigationToolbar2Tk(canvas, window)
        toolbar.update()
        canvas.get_tk_widget().pack(side=tkinter.TOP, fill=tkinter.BOTH, expand=1)

    def descripcion_palabras(self):
        import pandas as pd
        import matplotlib.pyplot as plt

        df = pd.read_csv("animales.csv", sep=",")

        total_palabras = []

        for n, linea in enumerate(df['descripcion']):
            palabras = linea.split(" ")
            for palabra in palabras:
                total_palabras.append(palabra)
        
        print(total_palabras)        
        
        for i, l in enumerate(total_palabras):
            total_palabras[i] = total_palabras[i].replace('.', '')
            total_palabras[i] = total_palabras[i].replace(',', '')
            total_palabras[i] = total_palabras[i].replace(';', '')
            total_palabras[i] = total_palabras[i].replace(':', '')
            total_palabras[i] = total_palabras[i].replace('-', '')
            total_palabras[i] = total_palabras[i].replace('_', '')
            total_palabras[i] = total_palabras[i].replace('¿', '')
            total_palabras[i] = total_palabras[i].replace('?', '')
            total_palabras[i] = total_palabras[i].replace('!', '')
            total_palabras[i] = total_palabras[i].replace('¡', '')
            total_palabras[i] = total_palabras[i].replace('á', 'a')
            total_palabras[i] = total_palabras[i].replace('à', 'a')
            total_palabras[i] = total_palabras[i].replace('é', 'e')
            total_palabras[i] = total_palabras[i].replace('è', 'e')
            total_palabras[i] = total_palabras[i].replace('í', 'i')
            total_palabras[i] = total_palabras[i].replace('ì', 'i')
            total_palabras[i] = total_palabras[i].replace('ó', 'o')
            total_palabras[i] = total_palabras[i].replace('ò', 'o')
            total_palabras[i] = total_palabras[i].replace('ú', 'u')
            total_palabras[i] = total_palabras[i].replace('ù', 'u')
            print(i)
        
        print(total_palabras)
        print(type(total_palabras))
        
        conjunto_palabras = set(total_palabras)
        for i, l in enumerate(conjunto_palabras):
            print(l, total_palabras.count(l))
        
        print(conjunto_palabras)

#------------------------ Main program
window = tk.Tk()
app = Application(window)
app.mainloop()


