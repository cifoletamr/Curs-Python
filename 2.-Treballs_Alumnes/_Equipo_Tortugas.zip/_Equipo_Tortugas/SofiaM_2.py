# -*- coding: utf-8 -*-
"""
Created on Mon Jul 12 13:08:57 2021

@author: mati
"""

from tkinter import Tk, StringVar,IntVar,Text, Label,Radiobutton, Entry, DISABLED
import tkinter as ttk
from dades_jocDB import guardar_form


#definir la clase----------------------

class Application(ttk.Frame):
    def __init__(self, window):
        super().__init__(window)
        self.win = window
        self.win.title("Formulario de Preferencias de Juego")
        self.win.geometry('400x600')
        
        frame = ttk.Frame(window)
        frame.config(width=400, height=600)
    
    
        self.nom = StringVar()
        self.edad = StringVar()
        self.res1 = IntVar()
        self.res2 = IntVar()
        self.res3 = IntVar()
        self.res4 = StringVar()
        self.msg =StringVar()
        
        self.animales= ('Perro','Gato','Tortuga')
        self.color = ('Azul','Rojo','Verde')
        self.comida = ('Carne','Pescado','Verdura')
    
        Label(frame ,text = "Introduce tu nombre").grid(row = 0,column = 0)
        Entry(frame,textvariable=self.nom).grid(row =  0,column = 1)
        
        Label(frame ,text = "Introduce tu edad").grid(row = 1,column = 0)
        Entry(frame,textvariable=self.edad).grid(row =  1,column = 1)
    
        Label(frame ,text = "Escoje un animal").grid(row = 2,column = 0)
        Radiobutton(frame, text=self.animales[0], variable=self.res1, 
                    value=0).grid(row = 2,column = 1)
        Radiobutton(frame, text=self.animales[1], variable=self.res1, 
                    value=1).grid(row = 2,column = 2)
        Radiobutton(frame, text=self.animales[2], variable=self.res1, 
                    value=2).grid(row = 2,column = 3)    
       
        Label(frame ,text = "Escoje un color").grid(row = 3, column = 0)
        Radiobutton(frame, text=self.color[0], variable=self.res2,
                    value=0).grid(row = 3,column = 1)
        Radiobutton(frame, text=self.color[1], variable=self.res2,
                    value=1).grid(row = 3,column = 2)
        Radiobutton(frame, text=self.color[2], variable=self.res2,
                    value=2).grid(row = 3,column = 3)  
        
        Label(frame ,text = "Escoje una comida").grid(row = 4, column = 0)
        Radiobutton(frame, text=self.comida[0], variable=self.res3,   
                    value=0).grid(row = 4,column = 1)  
        Radiobutton(frame, text=self.comida[1], variable=self.res3,   
                    value=1).grid(row = 4,column = 2)   
        Radiobutton(frame, text=self.comida[2], variable=self.res3,   
                    value=2).grid(row = 4,column = 3)
    
        Label(frame ,text = "Pon un título al juego").grid(row = 5,column = 0)
        Entry(frame,textvariable=self.res4).grid(row =  5,column = 1)
    
        ttk.Button(frame ,text="Cancelar", command=self.cancelar).grid(row=6, column=0)
        ttk.Button(frame ,text="Enviar", command=self.enviar_form).grid(row=6, column=1)
    
        Label(frame, textvariable=self.msg, state=DISABLED).grid(row = 7,column = 1)
    
        frame.pack()   

#definir las funciones---------------------

    def borrar_form(self):
        try:
            self.nom.set("")
            self.edad.set("")
            self.res1.set(-1)
            self.res2.set(-1)
            self.res3.set(-1)
            self.res4.set("")
             
        except Exception as e:
                print("Error: ", e)
    
    def enviar_form(self) :
       try:
        
            form = (self.nom.get(), self.edad.get(), self.animales[self.res1.get()], self.color[self.res2.get()], 
                          self.comida [self.res3.get()], self.res4.get())
            guardar_form (form)
            self.generar_csv(form)
            print ("Formulario:", form)
            self.borrar_form()
            self.msg.set( "Fomulario Enviado")       
       except Exception as e:
               print("Error: ", e)   
    
    def cancelar(self) :
            try:
                self.borrar_form()
                self.win.destroy()
            except Exception as e:
                print("Error: ", e)   
    
    def generar_csv(self,form):
        f=open('.\\dat\\dades_joc.csv','a',encoding='utf-8')
        print (";".join(form))
        f.write('\n'+";".join(form)+'\n')
        f.close()

#------------------------------------------------- Main
if __name__ == "__main__":
    window = Tk()
    app = Application(window)
    app.mainloop()
