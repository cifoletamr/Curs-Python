from gluon.contrib.populate import populate
if db(db.auth_user).isempty():
     populate(db.t_provincies,10)
     populate(db.t_poblacions,10)
