### we prepend t_ to tablenames and f_ to fieldnames for disambiguity


########################################
db.define_table('t_provincies',
    Field('f_id_provincia', type='string',
          label=T('Id Provincia')),
    Field('f_nom_provincia', type='string',
          label=T('Nom Provincia')),
    format='%(f_id_provincia)s',
    migrate=settings.migrate)

db.define_table('t_provincies_archive',db.t_provincies,Field('current_record','reference t_provincies',readable=False,writable=False))

########################################
db.define_table('t_poblacions',
    Field('f_id_poblacio', type='string',
          label=T('Id Poblacio')),
    Field('f_id_provincia', type='string',
          label=T('Id Provincia')),
    Field('f_nom_poblacio', type='string',
          label=T('Nom Poblacio')),
    format='%(f_id_poblacio)s',
    migrate=settings.migrate)

db.define_table('t_poblacions_archive',db.t_poblacions,Field('current_record','reference t_poblacions',readable=False,writable=False))
