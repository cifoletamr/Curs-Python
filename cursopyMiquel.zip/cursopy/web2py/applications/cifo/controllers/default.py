# -*- coding: utf-8 -*-
### required - do no delete
def user(): return dict(form=auth())
def download(): return response.download(request,db)
def call(): return service()
### end requires
def index():
    return dict()

def error():
    return dict()

def provincies_manage():
    form = SQLFORM.smartgrid(db.t_provincies,onupdate=auth.archive)
    return locals()

def poblacions_manage():
    form = SQLFORM.smartgrid(db.t_poblacions,onupdate=auth.archive)
    return locals()

