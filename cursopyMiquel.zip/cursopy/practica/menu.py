# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""
import tkinter as tk
import laberint as lab

class Application(tk.Frame):
    def __init__(self, window):
        super().__init__(window)
        self.win = window
        self.dimension_pantalla ()
        self.pedir_menu ()
    def dimension_pantalla (self):
        self.win.title("Gestió de Centres")
        self.win.geometry('400x400')
        self.win.minsize(width=300, height=400)
        self.win.maxsize(width=300, height=400)
    def pedir_menu (self) :
        menubar = tk.Menu(self.win)
        self.win.config(menu=menubar)
        javiermenu= tk.Menu(menubar, tearoff=0)
        javiermenu.add_command(label="Javier opcion 1",
                             command=self.javier_opcion1)
        lidiamenu= tk.Menu(menubar, tearoff=0)
        lidiamenu.add_command(label="Lidia opcion 1",
                                command=self.lidia_opcion1)
        miquelmenu= tk.Menu(menubar, tearoff=0)
        miquelmenu.add_command(label="Miquel opcion 1",
                               command=self.miquel_opcion1)
        josemenu= tk.Menu(menubar, tearoff=0)
        josemenu.add_command(label="Jose opcion 1",
                               command=self.jose_opcion1)
        pedromenu= tk.Menu(menubar, tearoff=0)
        pedromenu.add_command(label="Pedro opcion 1",
                               command=self.pedro_opcion1)
        menubar.add_cascade(label="Javier", menu=javiermenu)
        menubar.add_cascade(label="Lidia", menu=lidiamenu)
        menubar.add_cascade(label="Miquel", menu=miquelmenu)
        menubar.add_cascade(label="Jose", menu=josemenu)
        menubar.add_cascade(label="Pedro", menu=pedromenu)
    def javier_opcion1 (self) :
        lab.main()
    def lidia_opcion1 (self) :
        pass
    def miquel_opcion1(self) :
        pass
    def jose_opcion1(self) :
        pass 
    def pedro_opcion1(self) :
        pass           
#------------------------Main program
window = tk.Tk()
app = Application(window)
app.mainloop()