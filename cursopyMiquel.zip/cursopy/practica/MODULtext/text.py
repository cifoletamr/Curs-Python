# -*- coding: utf-8 -*-
"""
Creat el 15/07/2021

@author: Miquel Casellas
"""

from tkinter import Tk, StringVar, Label, Entry, DISABLED,  Button, Text
from tkinter import filedialog
from tkinter import ttk
import collections as coll
import re


class Application (ttk.Frame):

    def __init__(self, window):
        super().__init__(window)
        self.win = window
        self.win.title("Anàlisi de text")
        self.win.geometry('1000x500')        
        self.paraula = StringVar()
        self.filename = StringVar()
        self.resultat = StringVar()
        self.l = list()
        self.mes3 = list()
        self.mesusades = StringVar()
        self.nparaules = StringVar()
        
        Label(window ,text = "Sube un archivo txt").grid(row = 0,column = 0)
        
        Entry(window, textvariable=self.filename, state=DISABLED, width=60).grid(row = 0, column = 2)
        Entry(window, textvariable=self.resultat, state=DISABLED).grid(row = 2, rowspan=2, column= 2)
        self.t1 = Text(window)
        self.t1.grid(row=2, column=2)
        Entry(window, textvariable=self.mesusades, state=DISABLED, width=100).grid(row=3, column=2)
        Entry(window, textvariable=self.nparaules, state=DISABLED, width=100).grid(row=4, column=2)
        
        Button(window, text="Selecciona el archivo", command=self.seleccionar).grid(row = 0, column = 1)
        Button(window, text="Paraules més usades", command=self.paraules_mes_usades).grid(row = 3, column = 1)
        Button(window, text="Nº de paraules", command=self.n_paraules).grid(row = 4, column = 1)
        Button(window, text="Generar archivo txt", command=self.generar_archivo).grid(row = 5, column = 1)
       
    def seleccionar(self):
        """Rebre l'arxiu txt que l'usuari puja"""
        filename =  filedialog.askopenfilename(parent=window, initialdir = ".\\",title = "Select file",
                                                    filetypes = (("txt","*.txt"), ("all types","*.*")))
        self.filename.set(filename)
        self.leer_archivo()
        
    def leer_archivo(self):
        """Llegir l'arxiu que l'usuari ha pujat i guardar el seu text per treballar sobre ell"""
        print (self.filename.get())
        f = open(self.filename.get(), "r", encoding='utf-8')
        self.contenido = f.read()
        f.close()
        self.resultat.set(self.contenido)
        self.t1.insert(1.0, self.resultat.get())
        
    def paraules_mes_usades(self):
        """Netejar el text de signes de puntuació, majúscules i paraules curtes per contar
        les vuit paraules més repetides"""
        # Ensenyar les 5 paraules més usades https://docs.hektorprofe.net/python/modulos-y-paquetes/modulo-collections/
        # Mirar proves
        self.l = self.contenido.split()
        self.c = re.sub(r'[^\w\s]', '', self.contenido)
        self.c = self.c.lower()
        self.l2 = self.c.split()
        for i in self.l2:
            if len(i) > 4:
                self.mes3.append(i)
                self.mes3.append(" ")
            else:
                pass        
        self.strA = "".join(self.mes3)                     
        contador = coll.Counter(self.strA.split())
        self.mesusades.set(contador.most_common(8))
        
    def n_paraules(self):
        """Contar el número de paraules del text"""
        self.nparaules.set(len(self.l))
    
    def generar_archivo(self):
        """Crear un nou arxiu amb el text, les paraules més usades i el nº de paraules"""
        fname = self.filename.get()
        b = fname.rfind("/")
        e = fname.rfind(".")
        fname = fname[b+1:e]
        finalfile = open("dat\\"+fname+"_new.txt", "w", encoding="utf-8")
      
        finalfile.write("Texto: \n"+self.contenido+"\n\n\nPalabras más usadas: \n"+self.mesusades.get()+"\n\n\nNumero de palabras: \n"+self.nparaules.get())
          

if __name__ == "__main__":
    window = Tk()
    app = Application(window)
    app.mainloop()
    #window.destroy()
