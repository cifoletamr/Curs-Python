#!c:/conda3/python.exe
# -*- coding: UTF-8 -*-
# filename：hello_get.py
# hthttp://localhost/cgi-bin/hello_get.py?name=misite&url=www.miweb.com


# CGI Módulo de procesamiento
import cgi, cgitb 

# crear FieldStorage  Instanciación de
form = cgi.FieldStorage() 

# recuperar datos
site_name = form.getvalue('name')
site_url  = form.getvalue('url')
print('Content-type: text/html\r\n\r')
print ("")
print ("<html>")
print ("<head>")
print ("<meta charset=\"utf-8\">")
print ("<title>Ejemplos de prueba CGI de este tutorial</title>")
print ("</head>")
print ("<body>")
print ("Parametros del get ___")
print ("<br>site", site_name)
print ("<br>url", site_url)
print ("</body>")
print ("</html>")