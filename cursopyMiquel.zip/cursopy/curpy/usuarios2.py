import sqlite3

def consulta_personal():

    conexion = sqlite3.connect('practica.mdb')
    cursor = conexion.cursor()
    
    # Recuperamos los registros de la tabla de usuarios
    cursor.execute("SELECT * FROM personal where autorizado = 'S'")
    
    # Recorremos todos los registros con fetchall
    # y los volcamos en una lista de usuarios
    personal = cursor.fetchall()
    conexion.close()
    return (personal)

