#!/conda3/python
# -*- coding: UTF-8 -*-
# filename:test.py

import os

print ("Content-type: text/html")
print ("")
print ("<meta charset=\"utf-8\">")
print ("<b>Variables de entorno</b><br>")
print ("<ul>")
for key in os.environ.keys():
    #print ("<li><span style='color:green'>%30s </span> : %s </li>".format(key,os.environ[key]))
	print ("<li><span style='color:green'>%30s </span> : %s </li>" % (key,os.environ[key]))

print ("</ul>")
