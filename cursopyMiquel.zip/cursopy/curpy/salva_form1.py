#!c:/conda3/python.exe
# -*- coding: UTF-8 -*-
# filename：hello_get.py
# hthttp://localhost/cgi-bin/hello_get.py?name=misite&url=www.miweb.com


# CGI Módulo de procesamiento
import cgi, cgitb 

# crear FieldStorage  Instanciación de
form = cgi.FieldStorage() 

# recuperar datos
nombre = form.getvalue('fname')
apellido  = form.getvalue('lname')
correo  = form.getvalue('email')
print('Content-type: text/html\r\n\r')
print ("")
print ("<html>")
print ("<head>")
print ("<meta charset=\"utf-8\">")
print ("<title>Ejemplos de prueba CGI de este tutorial</title>")
print ("</head>")
print ("<body>")
print ("Parametros del get ___")
datos = ""
if nombre != None :
	print ("<br>nombre", nombre)
	datos += nombre +";"
if apellido != None :
	print ("<br>apellido", apellido)
	datos += apellido +";"
if correo != None :
	print ("<br>correo", correo)
	datos += correo +";"
print ("</body>")
print ("</html>")
fichero = open("form1.dat", "a")
fichero.write(datos+"\n")
fichero.close()
