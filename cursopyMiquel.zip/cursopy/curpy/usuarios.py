#!/conda3/python
print ('Content-type:text/html')
print ('\n')
print ('<html>')
print ('<head>')
print ('<meta charset="utf-8">')
print ('<title>Hello Word - CGI</title>')
print ('</head>')
print ('<body>')
#import sqlite3
# personal = consulta_personal()
# for i in personal :
#        print (personal.get("nom"), personal.get("cognom1"), personal.get("cognom2"))
     # print(i[0], i[1], i[2], i[3])

print ( "<p>A frog plops</p>")
print ( "<p>Into the still water</p>")
print ('</body>')
print ('</html>')
