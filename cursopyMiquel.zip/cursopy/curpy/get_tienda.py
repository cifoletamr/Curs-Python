#!c:/conda3/python.exe
# -*- coding: UTF-8 -*-
# filename：hello_get.py
# http://localhost/cgi-bin/curpy/get_tienda.py?tienda=1


# CGI Módulo de procesamiento
import cgi, cgitb 

# crear FieldStorage  Instanciación de
form = cgi.FieldStorage() 

# recuperar datos
tienda = form.getvalue('tienda')
print('Content-type: text/html\r\n\r')
print ("")
print ("<html>")
print ("<head>")
print ("<meta charset=\"utf-8\">")
print ("<title>Ejemplos de prueba CGI de este tutorial</title>")
print ("</head>")
print ("<body>")
print ("Parametros del get ___")
print ("<br>tienda", tienda)

if tienda != None :
    fnombre = "tienda"+tienda+".dat"
    print (fnombre)
    fichero = open(fnombre, "r")
    lineas = fichero.read();
    lineas = lineas.split("\n")
    for item in lineas :
        print('<br>', item)
print ("</body>")
print ("</html>")