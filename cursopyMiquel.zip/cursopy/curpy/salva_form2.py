#!c:/conda3/python.exe
# -*- coding: UTF-8 -*-
# filename：hello_get.py
# hthttp://localhost/cgi-bin/hello_get.py?name=misite&url=www.miweb.com


# CGI Módulo de procesamiento
import cgi, cgitb 

# crear FieldStorage  Instanciación de
form = cgi.FieldStorage() 

# recuperar datos
d={}
d['nombre'] = form.getvalue('user_name')
d['correo']  = form.getvalue('user_mail')
d['fichero']  = form.getvalue('user_file')
d['mensaje']  = form.getvalue('user_message')
d['comida']  = form.getvalue('meal')
print('Content-type: text/html\r\n\r')
print ("")
print ("<html>")
print ("<head>")
print ("<meta charset=\"utf-8\">")
print ("<title>Ejemplos de prueba CGI de este tutorial</title>")
print ("</head>")
print ("<body>")
print ("Parametros del get ___")
texto = ""
for item in d :
	print ("<br>", item, d[item])
	texto += d[item] +";"
print ("</body>")
print ("</html>")
fichero = open("form2.dat", "a")
fichero.write(texto+"\n")
fichero.close()
