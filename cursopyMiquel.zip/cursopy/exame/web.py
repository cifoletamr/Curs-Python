# -*- coding: utf-8 -*-

import sqlite3

def imprimir_html(nombre_html):

    f = open(nombre_html, 'r', encoding='utf-8')
    lineas = f.readlines()
    
    for l in lineas:
        print(l)

def imprimir_tablas(nombre_tabla):
    db_name = 'exame.dat'
    try:
        conexion = sqlite3.connect(db_name)
        cursor = conexion.cursor()
        cursor.execute("SELECT * FROM " + nombre_tabla)        
        registros = cursor.fetchall()
        
        for r in registros:
            if nombre_tabla == "poblacions":
                print("<p>", r[0], r[1], r[2], "</p>")
            else:
                print("<p>", r[0], r[1], "</p>")
        conexion.close()
                
    except Exception as e:
        print("Error en la base de datos: ", e)
         
#   ----------------------------        
imprimir_html('header.html')

#Imprimir poblaciones
print('<h3>POBLACIONS</h3>')
print("<div class='w3-panel w3-red'>")
imprimir_tablas("poblacions")
print("</div>")

#Imprimir provincias
print('<h3>PROVINCIES</h3>')
print("<div class='w3-panel w3-green'>")
imprimir_tablas("provincies")
print("</div>")



imprimir_html('footer.html') 


