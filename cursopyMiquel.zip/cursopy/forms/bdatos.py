import sqlite3

def abre_bd_personas():
    """ abre la conexion con la base de datos """
    
    db_name = "dat\\personas.db"
    conexion = None
    
    try :
        conexion = sqlite3.connect(db_name)
    except Exception as e:
        print("Error en la base de datos: ", e) 
    return (conexion)
 
    

def crea_tablas():
    """ si no existe, crea la tabla de personas """

    conexion = abre_bd_personas()
    cursor = conexion.cursor()
    
    # Ahora crearemos una tabla de usuarios con nombres, edades y emails
    sql = "CREATE TABLE IF NOT EXISTS personas (dni CHAR(10), nom VARCHAR(50), " 
    sql += "cognom1 VARCHAR(50),cognom2 VARCHAR(50), correu VARCHAR(100),  "
    sql += "telefon VARCHAR(30), codipostal CHAR(5))"
    cursor.execute(sql)
    
    # Guardamos los cambios haciendo un commit
    conexion.commit()
    conexion.close()
    
def crea_personas(lista_personas):
    """ inserta un array de tuplas de personas en la base de datos """
    
    conexion = abre_bd_personas()
    cursor = conexion.cursor()
    
    # Ahora utilizamos el método executemany() para insertar varios
    cursor.executemany("INSERT INTO personas VALUES (?,?,?,?,?,?,?)", lista_personas)
    
    # Guardamos los cambios haciendo un commit
    conexion.commit()
    conexion.close()
    
def crea_persona(persona):
    """ inserta una tupla de persona en la base de datos """
    try:
        conexion = abre_bd_personas()
        cursor = conexion.cursor()
        
        str_sql = "INSERT INTO personas(dni, nom, cognom1,cognom2, correu, telefon,"\
                  "  codipostal) VALUES (?,?,?,?,?,?,?);"
        print(str_sql, persona)
        cursor.execute (str_sql, persona)
    
        # Guardamos los cambios haciendo un commit
        conexion.commit()
        conexion.close()
    except Exception as e:
        print(e)
        

def consulta_personas() :
    """ retorna una lista de tuplas de personas """
    
    conexion = abre_bd_personas()
    cursor = conexion.cursor()

    # Recuperamos los registros de la tabla de usuarios
    cursor.execute("SELECT * FROM personas")
    
    # Recorremos todos los registros con fetchall
    # y los volcamos en una lista de usuarios
    personal = cursor.fetchall()
    conexion.close()
    return (personal)
    
if __name__ == '__main__':

    crea_tablas()

    #
    # Crea datos de prueba
    #
    crea_persona (('0','Pruebas', 'Usuario', 'de pruebas', 'pruebas@ejemplo.com', '6', '7'))
    # Creamos una lista con varios usuarios (dni, nom, cognom1,congom2, correu, telf, codipostal)
    # =============================================================================
    personas = [('1946-2006','Mario', 'Benedetti', 'Farugia', 'mario@ejemplo.com', '+55 677 890', '08021'), \
                     ('46227542-A', 'Marta', 'Artigas', 'Font', '5589@telefonica.es', '678553312', '08005'),\
                     ('37128934-J','Joan', 'Artigas', 'Piqué', 'joan@dosnoms.cat', '933192211', '08003')]
    #     
    # =============================================================================
    crea_personas (personas)   
    
    personas = consulta_personas()
    for i in personas:
        print(i)