# -*- coding: utf-8 -*-
"""
Name : Manteniment de Persones
Created : Mon Jul 12 18:18:52 2021
@author: Mercè Ribas
"""

from tkinter import Tk, StringVar, Label, Entry, DISABLED
from tkinter import ttk
from bdatos import crea_persona

class Application (ttk.Frame):

    def __init__(self, window):
        super().__init__(window)
        self.win = window
        self.win.title("Gestió de Centres")
        self.win.geometry('300x250')
       
        frame = ttk.Frame(self.win)      
        frame.config(width=450,height=400) 

        self.dni =StringVar()
        self.nom =StringVar()
        self.cognom1 =StringVar()
        self.cognom2 =StringVar()
        self.correu =StringVar()
        self.telf =StringVar()
        self.codipostal =StringVar()
        self.msg =StringVar()

        Label(frame ,text = "Dni     ").grid(row = 0,column = 0)
        Label(frame ,text = "Nom     ").grid(row = 1,column = 0)
        Label(frame ,text = "Cognom 1").grid(row = 2,column = 0)
        Label(frame ,text = "Cognom 2").grid(row = 3,column = 0)
        Label(frame ,text = "Correu  ").grid(row = 4,column = 0)
        Label(frame ,text = "Telèfon ").grid(row = 5,column = 0)
        Label(frame ,text = "cPostal ").grid(row = 6,column = 0)

        Entry(frame, textvariable=self.dni).grid(row = 0,column = 1)
        Entry(frame, textvariable=self.nom).grid(row = 1,column = 1)
        Entry(frame, textvariable=self.cognom1).grid(row = 2,column = 1)
        Entry(frame, textvariable=self.cognom2).grid(row = 3,column = 1)
        Entry(frame, textvariable=self.correu).grid(row = 4,column = 1)
        Entry(frame, textvariable=self.telf).grid(row = 5,column = 1)
        Entry(frame, textvariable=self.codipostal).grid(row = 6,column = 1)

        ttk.Button(frame ,text="Cancelar", command=self.cancelar).grid(row=7, column=0)
        ttk.Button(frame ,text="Enviar", command=self.enviar).grid(row=7, column=1)

        Entry(frame, textvariable=self.msg, state=DISABLED).grid(row = 9,column = 1)

        frame.pack()    
        
    def esborra_caixes(self):
        try:
            self.dni.set("")
            self.nom.set("")
            self.cognom1.set("")
            self.cognom2.set("")
            self.correu.set("")
            self.telf.set("")
            self.codipostal.set("")
        except Exception as e:
            print("Error: ", e)

    def enviar(self) :
        try:
            # Creamos una lista con tupla usuarios 
            #(dni, nom, cognom1,congom2, correu, telf, codipostal)
            persona = (self.dni.get(), self.nom.get(), self.cognom1.get(), self.cognom2.get(), 
                       self.correu.get(), self.telf.get(), self.codipostal.get())
            crea_persona (persona)
            print ("Enviat ", persona)
            self.esborra_caixes()
            self.msg.set( "Dades Enviades")       
        except Exception as e:
            print("Error: ", e)   

    def cancelar(self) :
        try:
            self.esborra_caixes()
            self.win.destroy()
        except Exception as e:
            print("Error: ", e)   


#------------------------------------------------- Main
if __name__ == "__main__":
    window = Tk()
    app = Application(window)
    app.mainloop()

