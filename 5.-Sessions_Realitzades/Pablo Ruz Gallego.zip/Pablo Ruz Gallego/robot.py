distancia = float(input('Cuanta sera la distancia en cm recorrida:'))
paso = float(input('indica los pasos en cm: '))
solucion =int(distancia/paso)

print(solucion)





