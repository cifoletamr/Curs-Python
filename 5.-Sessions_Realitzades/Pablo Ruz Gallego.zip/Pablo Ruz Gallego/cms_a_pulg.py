# Nombre del programa: cms_a_pulg.py
# Descripción : programa que calcula el cambio de unidad entre centimetros y pulgadas
# Autor : Pablo Ruz
# Fecha creación : 30/3/22

centimetros = float(input('medida en cm:'))
pulgadas = centimetros/2.54
solucion =round((pulgadas),3)


print(solucion)