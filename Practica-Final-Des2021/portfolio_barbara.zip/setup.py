{
 "cells": [
  {
   "cell_type": "code",
   "execution_count": null,
   "id": "f2d7a71f",
   "metadata": {},
   "outputs": [],
   "source": [
    "\"\"\"\n",
    "Set up per a crear un paquet amb els moduls\n",
    "\"\"\"\n",
    "\n",
    "from setuptools import setup\n",
    "\n",
    "setup(name=\"Portfolio\",                    # Nombre\n",
    "    version=\"0.1\",                         # Versión de desarrollo\n",
    "    description=\"Paquete del portfolio\",   # Descripción del funcionamiento\n",
    "    author=\"Barbara Blay\",                 # Nombre del autor\n",
    "    author_email='blay.barbara@gmail.com', # Email del autor\n",
    "    license=\"GPL\",                         # Licencia: MIT, GPL, GPL 2.0...\n",
    "    url=\"http://notyetbutverysoon.com\",    # Página oficial (si la hay)\n",
    "    packages=['portfolio'],\n",
    "#   install_requires=['nombre modulo'] ----> poner aqui las librerias que queramos que se instalen con el setup\n",
    ")"
   ]
  }
 ],
 "metadata": {
  "kernelspec": {
   "display_name": "Python 3",
   "language": "python",
   "name": "python3"
  },
  "language_info": {
   "codemirror_mode": {
    "name": "ipython",
    "version": 3
   },
   "file_extension": ".py",
   "mimetype": "text/x-python",
   "name": "python",
   "nbconvert_exporter": "python",
   "pygments_lexer": "ipython3",
   "version": "3.8.8"
  }
 },
 "nbformat": 4,
 "nbformat_minor": 5
}
