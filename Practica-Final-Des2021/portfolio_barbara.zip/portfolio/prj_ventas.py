
# Realitza un programa python usant tkinter que s'anomeni prj_ventas.py.

#  - La finestra ha de permetre navegar per escollir un fitxer CSV de vendes per llegir-lo en un Dataframe Pandas. -> ok
#  - També ha de permetre seleccionar
#      • Agrupar per : Centre / Tipus Client / Districte : tipus Radio Button -> ok
#      • Desglossament per mesos o Total anual: tipus Radio Button -> ok
#      • Número de Factura i/o Total Vendes : tipus Check Button. -> ok
#      • Calcular : tipus Botó -> ok
#      • Resultat : tipus Caixa de Text -> ok
#      • Gràfic de Línies o Barres o Pastís : tipus Botons



""" Módulo de análisis de datos formato DataFrame """

import pandas as pd
import numpy as np
from tkinter import *
from tkinter import filedialog

#------------------- función para el botón 'Navegar'
def abrir():
    """ Función para buscar el archivo CSV en el ordenador """
    global df
    file = filedialog.askopenfilename(
    initialdir="./dat", filetypes=(("Ficheros CSV", "*.csv"),("Todos los ficheros","*.*")), 
    title = "Abrir un fichero.")
    fichero = open(file, 'r')
    df = pd.read_csv(fichero, sep=";", header=0)
    texto.delete(1.0, 'end')           
    texto.insert('insert', df)  
    fichero.close()
#------------------- función para el radiobutton 'agrupar'
def calcular():
    """ Función para realizar los calculos de agrupar, desglose y totales """
    global df
    agrupar_por = agrupar.get() ;  # 0=Centro, 1=TipoCliente , 2 = Distrito
    desglose = desglo.get() ; # 0 = total anual ; 1 = por meses
    factura = 0 ;  # 0 = no contar facturas , 1 = contar facturas 
    totales = 1 ;  # 0 = no contar totales , 1 = contar totales

    columnas = []
    operaciones = []

    if agrupar_por == 0 :
        columnas.insert(0,'centro')
    elif agrupar_por == 1 :
        columnas.insert(0,'tipo')
    elif agrupar_por == 2 :
        columnas.insert(0,'c_postal')

    if desglose == 1 :
        columnas.append('mes')
    else:
        columnas.append('anyy')

    if factura == 1 :
        operaciones.append('count')

    if totales == 1 :
        operaciones.append('sum')

    if len(operaciones) > 0 :
        dfcalc = df.groupby(columnas).agg({'total_fra': operaciones})
        print (dfcalc)
        texto.delete(1.0, 'end')           
        texto.insert('insert', dfcalc)
    else :
        print ('No ha seleccionado operaciones')


    
# ------------- inicio    
root = Tk()
root.config(bd=15)
root.geometry('800x800')

# --------------------------------------------------- caja para cargar archivo
texto = Text(root)
texto.pack()
texto.config(width=150, height=25, selectbackground="black")

# ------------------------------------------------------------------------------------------ BOTONES
button1 = Button(root, text="Navegar", command= abrir).pack()
button2 = Button(root, text="Calcular", command= calcular).pack()

# ------------------------------------------------------------------------------------------ RADIOBOTONES
agrupar= IntVar()
Radiobutton(root, text="Agrupar per Centre", variable=agrupar, value=0).pack(anchor="w")
Radiobutton(root, text="Agrupar per Tipus Client", variable=agrupar, value=1).pack(anchor="w")
Radiobutton(root, text="Agrupar per Districte", variable=agrupar, value=2).pack(anchor="w")

desglo = IntVar()
Radiobutton(root, text="Totales", variable=desglo, value=0).pack(anchor="w")
Radiobutton(root, text="Desglose por meses", variable=desglo, value=1).pack(anchor="w")

# ------------------------------------------------------------------------------------------ CHECKBUTTON
factures = IntVar()     # 0 = no contar facturas , 1 = contar facturas
totala = IntVar()   # 0 = no contar totales , 1 = contar totales
Label(root,text="Facturas/Ventas").pack(anchor="w")
Checkbutton(root, text="Facturas", variable=factures, onvalue=1, offvalue=0).pack(anchor="w")
Checkbutton(root, text="Totales",variable=totala, onvalue=1, offvalue=0).pack(anchor="w")

root.mainloop()