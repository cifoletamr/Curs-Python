# -*- coding: utf-8 -*-
"""
Spyder Editor

This is a temporary script file.
"""

# -*- coding: utf-8 -*-
import easygui
import form_jocs

opciones = ['Análisis Texto', 'Ventas Pandas', 'Ejercicio Libre', 'Salir']
opcion_texto = ""

while opcion_texto != 'Salir' :
    opcion_texto = easygui.buttonbox('Seleccione opción', 'Practica de Portfolio', opciones)
    
    opcion = opciones.index(opcion_texto) 
    print(opcion_texto, opcion) 
    if opcion == 0 :
        import prj_texto
    elif opcion == 1 :
        import prj_ventas
    elif opcion == 2:
        form_jocs.principal()

