# -*- coding: utf-8 -*-
"""
Set up per a crear un paquet amb els moduls
"""

from setuptools import setup

setup(name="Portfolio",                 # Nombre
    version="0.1",                      # Versión de desarrollo
    description="Paquete de prueba",    # Descripción del funcionamiento
    author="Hector Costa",              # Nombre del autor
    author_email='me@hcosta.info',      # Email del autor
    license="GPL",                      # Licencia: MIT, GPL, GPL 2.0...
    url="http://ejemplo.com",           # Página oficial (si la hay)
    packages=['portfolio'],
#   install_requires=['nombre modulo'] ----> poner aqui las librerias que queramos que se instalen con el setup
)