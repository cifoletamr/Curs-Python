# -*- coding: utf-8 -*-
""" Módulo de análisis de texto 

#Realitza un programa tkinter rj_texto.py per analitzar text

# - Crea una caixa de text que accepti fins a 800 caracters -> ok
# - Un botó que permeti navegar per seleccionar el fitxer de paraules a eliminar -> ok
# - Demana 'x' per pantalla, per eliminar les paraules de menys de x lletres -> ok
# - Botó calcular per a:
#                          - pasar a minúscules, respectar accents, substituir -> ok
#                          - descartar paraules del fitxer i menys de 'x' lletres -> ok
#                          - mostrar resultats en una caixa de text anomenada 'resultat': -> ok
#                                                                                                - total paraules -> ok
#                                                                                                 - mapa conceptes -> ok

"""

from tkinter import *
from tkinter import filedialog
from collections import Counter


#------------------- función para el botón 'Navegar'
def abrir():
    """ Función para buscar el archivo DAT en el ordenador """
    file = filedialog.askopenfilename(
    initialdir="./tkinter/dat", filetypes=(("Ficheros DAT", "*.dat"),("Todos los ficheros","*.*")), 
    title = "Abrir un fichero.")
    fichero = open(file, 'r')
    contenido = fichero.read()
    texto.delete(1.0, 'end')           
    texto.insert('insert', contenido)  
    fichero.close()
    
#------------------- función para el botón 'Calcular'
def calcular():
    """ Función para realizar las modificaciones en el texto """
    fitxer = open("./dat/python.txt", "r", encoding="UTF-8")    # fichero inicial
    fitx = fitxer.read()
    fitxer.close()
    
    fich = open("./dat/descartar.dat", "r", encoding="UTF-8")   # palabras a eliminar
    descartar = fich.read()
    descartar = descartar.split("\n")
    descartar.remove("")
    fich.close()
    
    fitx=fitx.lower()                # ------------ minusculas
    fitx= fitx.replace("."," ")      # ------------ sustituir '.' por ' '
    fitx= fitx.replace(",","")       # ------------ sustituir ',' por ''
    
    paraules = fitx.split(" ")                                            # Convierte el texto inicial en una lista
    txt_net = [x for x in paraules if len(x) > 3 and x not in descartar]  # Texto limpio
      
    print("Se ha pasado el texto a minúsculas")
    print("Se ha sustituído '.' por espacio y ',' por nada")
    print("Se han eliminado las palabras del archivo 'descartar' y las que tienen menos de 4 letras")
    texto.delete(1.0, 'end')           
    texto.insert('insert', fitx) #insertamos texto modificado en el cuadro de texto superior
    
    contingut =""
    contingut += f"Hay {len(txt_net)} palabras \n"                    # cuantas palabras hay
    
    c = set(txt_net)                                                    
    difers = list(c)                                                            
    contingut += f"Hay un total de {len(difers)} palabras diferentes \n\nMapa Conceptual: \n" # cuantas palabras diferentes hay
                                          
    d = Counter(txt_net)                                              
    max_freq = d.values()
    print(max_freq)
    max_freq = sorted(max_freq, reverse=True)[0]
    for i in range (max_freq, 2, -1):
        for j in d :
            if d[j] == i :
                contingut += f" {j} : {d[j]} \n"     # palabras + 2 veces ordenadas por frecuencia
    texto2.delete(1.0, 'end')           
    texto2.insert('insert', contingut)
    print(contingut)


    
     

root = Tk()
root.config(bd=15)
# --------------------------------------------------- caja 800 caracteres
texto = Text(root)
texto.grid(row=0, column=1)
texto.config(width=80, height=10, selectbackground="black")
   


# --------------------------------------------------- cargar fichero python.txt
archivo = open("./dat/python.txt", "r", encoding="UTF-8")
contenido = archivo.read()
texto.get(1.0, 'end')           
texto.insert('insert', contenido)  
archivo.close()
# --------------------------------------------------- entrada 'x'
entry = Entry(root)
entry.grid(row=2, column=1)

label1 = Label(root, text="Elimina palabras que tengan menos de __ letras: ")
label1.grid(row=1, column=1)


# ------------------------------------------------------------------------------------------ botón para navegar
button1 = Button(root, text="Navegar", command= abrir).grid(row=1, column=2)
# ------------------------------------------------------------------------------------------ botón calcular
button2 = Button(root, text="Calcular", command= calcular).grid(row=2, column=2)


# --------------------------------------------------- caja 'Resultado'
texto2 = Text(root)
texto2.grid(row=3, column=1)
texto2.config(width=80, height=13, selectbackground="black")
label2 = Label(root, text="Resultado")
label2.grid(row=3, column=0)
 
#
root.mainloop()

