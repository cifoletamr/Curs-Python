# -*- coding: utf-8 -*-
"""
Created on Mon Dec 20 18:27:36 2021

@author: Alumne_tarda2
"""

from setuptools import setup

setup(name="Python",  # Nombre
    version="0.1",  # Versión de desarrollo
    description="Paquete de prueba",  # Descripción del funcionamiento
    author="Elías Huerta",  # Nombre del autor
    author_email='eliashz@gmail.com',  # Email del autor
    license="GPL",  # Licencia: MIT, GPL, GPL 2.0...
    url="http://linkedin.com",  # Página oficial (si la hay)
    packages=['prueba'],
)