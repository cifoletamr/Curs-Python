# -*- coding: utf-8 -*-
"""
Creado Lun Dic 20 18:25:05 2021
hjkgkhg
@author: Pablo
"""

import tkinter as ttk
from tkinter import *
import pandas as pd
from tkinter import filedialog
import plotly as plt


def navegar():
    
    filename = filedialog.askopenfilename(parent=window, 
                                      title = "Selecciona ",
                                      initialdir = "./dat/", 
                                      filetypes = (("csv","*.csv"),
                                                 ("all files","*.*")))

    df = pd.read_csv(filename, sep=";")
    pd.set_option('display.max_rows', 500)
    pd.set_option('display.max_columns', 500)
    pd.set_option('display.width', 1000) 



def calcular():
    """ Esta es la definición de calcular bien hecha"""
    
    global df
    columnas = []
    operaciones = []
    
    #----------------------------------Agrupar por
    if agrupar.get()== 1:
        columnas.append('centro')
    elif agrupar.get() == 2 :
        columnas.append('tipo')
    elif agrupar.get() == 3 :
        columnas.append('c_postal')
    #----------------------------------Desglose por
    
    if desglose.get() == 1:
        columnas.append('mes')
    elif desglose.get() == 2:
        columnas.append('anyy')
  
   #----------------------------------NumFras o totales
    if factura.get() == 1:
        operaciones.append('count')
    if ventas.get() == 1:
        operaciones.append('sum')
        
    if len(operaciones) > 0:
        dfcalc= df.groupby(columnas).agg({'total_fra':operaciones})
        caja_resultado.insert('insert', dfcalc)
    else:
        caja_resultado.insert('insert', 'No ha seleccionado operaciones.')
        
def lineas():
    df.plot()
    plt.show()
    
def barras():
    df.plot(kind='bar')
    plt.show()
    
def tartas():
    plt.pie(dfcalc)
    plt.show()

# ------------------------------
    
columnas = []
operaciones = []

       
root = Tk()
root.title("prj_texto")
root.geometry('800x800')

nom = StringVar()  ;  
agrupar = IntVar()  ;  # 0=Centro, 1=TipoCliente , 2 = Distrito
desglose = IntVar() ;  # 0 = total anual ; 1 = por meses
factura = IntVar()  ;  # 0 = no contar facturas , 1 = contar facturas 
ventas = IntVar()   ;  # 0 = no contar ventas , 1 = contar ventas
grafico = IntVar()  ;


Entry(root, textvariable=nom).pack()
Button(root, text="Navegar", command=navegar).pack()


Label(root, text ="Como quiere agrupar, ¿Por centro, tipo de cliente o distrito?").pack()
Radiobutton(root, text="Centro", variable=agrupar, value=1).pack()
Radiobutton(root, text="TipoCliente", variable=agrupar, value=2).pack()
Radiobutton(root, text="Distrito", variable=agrupar, value=3).pack()



Label(root, text ="Como quiere desglosar, ¿Por año o mes?").pack()
Radiobutton(root, text="Anual", variable=desglose, value=2).pack()
Radiobutton(root, text="Mes", variable=desglose, value=1).pack()

Label(root, text="Seleccione entre Nº total de ventas o el Nº de Factura:").pack()
Checkbutton(root, text="Nº total ventas", variable=ventas, 
            onvalue=1, offvalue=0).pack()
Checkbutton(root, text="Nº de factura", variable=factura, 
            onvalue=1, offvalue=0).pack()


Button(root, text="Calcular", command=calcular).pack()


label = Label(root, text="Resultado").pack()
Button(root, text="Calcular", command=calcular).pack()

caja_resultado = Text(root, width = 80, height=10)
caja_resultado.pack()

Label(root,text="Gráfico").pack
Button(root, text="Líneas", command=lineas).pack()
Button(root, text="Barras", command=barras).pack()
Button(root, text="Tartas", command=tartas).pack()
# ------------------------------

root.mainloop()
