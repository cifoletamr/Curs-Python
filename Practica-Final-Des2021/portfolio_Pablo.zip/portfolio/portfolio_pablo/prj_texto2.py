# -*- coding: utf-8 -*-
"""
Creado Lun Dic 20 18:25:05 2021
hjkgkhg
@author: Pablo
"""
def abrir():
    filename = filedialog.askopenfilename(parent=root, initialdir = "./dat/", 
    title = "Selecciona archivo",
    filetypes = (("csv","*.csv"),("all files","*.*")))
    nombre.set(filename)
def calcular():
    #---------- Lee el fichero a descartar
    fich=open(nombre.get(), "r", encoding="UTF-8")
    descartar=fich.read()
    descartar=descartar.split("\n")
    descartar.remove("")
    fich.close()
    
    #---------- Ojo solo si no han puesto texto en la caja.. Lee fichero de texto
    # if …
    fich_texto =open("./dat/python.txt", "r", encoding="UTF-8")
    texto= fich_texto.read()
    fich_texto.close()
    caja_texto.insert('insert', texto)
    texto2=texto.replace('.',' ')
    texto2=texto2.replace(',','')
    texto2=texto2.lower()
    palasin = [y for y in palabras if len(y) > x.get() and y not in descartar]
    
    #------------------escribir
    c=set(palasin) 
    len_difers=str(len(list(c)))
    contenido= "El número total de palabras es {len(palasin)} + \n"
    contenido+= "El número de palabras distintas es {len_difers}\n"
    caja_resultado.insert('insert', contenido)
    
    #------------------contar
    repe=Counter(palasin)
    max_freq = repe.values()
    max_freq = sorted(max_freq, reverse=True)[0]
    for i in range (max_freq, 2, -1):
    for j in repe :
    if repe[j] == i :
    contenido=str(j)+' '+str(repe[j])+'\n'
    caja_resultado.insert('insert', contenido)


# ------------------------------------------------------------------------- Inicio del programa

root = Tk()
root.title("Actividad 1")
nombre=StringVar()
x=IntVar()
contenido=StringVar()

# Crea una caja de texto que acepte hasta 800 caracteres.
caja_texto = Text(root)
caja_texto.grid(row = 0,column = 0)
caja_texto.config(padx=6, pady=4, bd=0)

# Un botón que permita navegar para seleccionar el fichero de palabras a eliminar.
Label(root ,text = "Seleccionar fichero").grid(row = 1,column = 0)
Entry(root,textvariable=nombre).grid(row = 1,column = 1)
Button(root,text="Navega",command=abrir).grid(row = 1,column = 2)

# Pide ‘x’ por pantalla, para eliminar las palabras de menos de x letras.
Label(root ,text = "Descartar palabras de menos de").grid(row = 3,column = 0)
Entry(root,textvariable=x).grid(row = 3,column = 1)

#Añade un botón Calcular, que debe realizar estas acciones:
Button(root,text="Calcular",command=calcular).grid(row = 4,column = 0)

#Mostrar resultados en una caja de texto llamada resultado
Label(root ,text = "Resultado").grid(row = 5,column = 0)
caja_resultado= Text(root)
caja_resultado.grid(row = 6,column = 0)
caja_resultado.config(padx=6, pady=4, bd=0)
root.mainloop()