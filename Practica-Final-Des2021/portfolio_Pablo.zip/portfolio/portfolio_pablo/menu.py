# -*- coding: utf-8 -*-
# -*- coding: utf-8 -*-
import easygui
import form_jocs

opciones = ['Análisis Texto', 'Ventas Pandas', 'BD Jocs', 'Salir']
opcion_texto = ""

while opcion_texto != 'Salir' : 
    opcion_texto = easygui.buttonbox('Seleccione opción:', 'Practica de Portfolio', opciones)
    opcion = opciones.index(opcion_texto) 
    print(opcion_texto, opcion) 
    if opcion == 0 :
        import prj_texto
    elif opcion == 1 :
        import prj_ventas
    elif opcion == 2:
        form_jocs.main() 
