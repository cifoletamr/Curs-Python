"""
Name : Manteniment de Clients
Created : Tues Oct 5 10:11:52 2021
@author: Ivan Sanmiguel
"""

import sqlite3

def obre_bd_games():
    """ abre la conexion con la base de datos """
    
    db_name = "./dat/jocs.db"
    conexion = None
    
    try :
        conexion = sqlite3.connect(db_name)
    except Exception as e:
        print("Error en la base de datos: ", e) 
    return (conexion)    

def crea_taules():
    """ si no existe, crea la tabla de games """

    conexion = obre_bd_games()
    cursor = conexion.cursor()
    
    # Ahora crearemos una tabla de juegos con nombre, plataforma...
    sql = "CREATE TABLE IF NOT EXISTS games (id INTEGER PRIMARY KEY AUTOINCREMENT, " 
    sql += "game_title VARCHAR(150) UNIQUE ON CONFLICT ROLLBACK, platform VARCHAR(70), "
    sql += "release_year INTEGER (4), price DECIMAL(5, 2), genre VARCHAR(70), publisher VARCHAR(80));"
    cursor.execute(sql)
        
    # Guardamos los cambios haciendo un commit
    conexion.commit()
    conexion.close()
    
def crea_games(llista_games):
    """ inserta un array de tuplas de juegos en la base de datos """
    
    conexion = obre_bd_games()
    cursor = conexion.cursor()
    
    # Ahora utilizamos el método executemany() para insertar varios
    # pasamos primer valor null que es la PK y se autoincrementa
    cursor.executemany("INSERT INTO games VALUES (null,?,?,?,?,?,?)", llista_games)
    
    # Guardamos los cambios haciendo un commit
    conexion.commit()
    conexion.close()
    
def crea_game(game):
    """ inserta una tupla de juego en la base de datos """
    
    conexion = obre_bd_games()
    cursor = conexion.cursor()
    
    str_sql = "INSERT INTO games(id, game_title, platform, release_year, price, genre, publisher) "\
              "VALUES (null,?,?,?,?,?,?);"
              
    print(str_sql, game)
    cursor.execute (str_sql, game)

    # Guardamos los cambios haciendo un commit
    conexion.commit()
    conexion.close()

def elimina_game(game_title):
    """ elimina un juego """
    
    conexion = obre_bd_games()
    cursor = conexion.cursor()
    
    str_sql = f"DELETE FROM games WHERE game_title = '{game_title}';"
    print(str_sql, game_title)
    cursor.execute (str_sql)

    # Guardamos los cambios haciendo un commit
    conexion.commit()
    conexion.close()

def consulta_games() :
    """ retorna una lista de tuplas de clients """
    
    conexion = obre_bd_games()
    cursor = conexion.cursor()

    # Recuperamos los registros de la tabla de games
    cursor.execute("SELECT * FROM games")
    
    # Recorremos todos los registros con fetchall
    # y los volcamos en una lista de juegos
    listado = cursor.fetchall()
    conexion.close()
    return (listado)

def consulta_game(game_title) :
    """ retorna una lista de tuplas de clients """
    
    conexion = obre_bd_games()
    cursor = conexion.cursor()

    # Recuperamos los registros de la tabla de juegos
    cursor.execute(f"SELECT * FROM games WHERE game_title = '{game_title}';")
    
    # Recorremos todos los registros con fetchall
    # y los volcamos en una lista de usuarios
    listado = cursor.fetchall()
    conexion.close()
    return (listado)

if __name__ == '__main__':

    crea_taules()
    # Crea datos de prueba
    #
    crea_game (('Prueba','Pruebas', '2000', '0', 'Beta', 'Prueba SL'))
    # Creamos una lista con varios juegos (id,game_title,platform,release_year,price,genre, publisher)
    # =============================================================================
    llista_games = [('Shovel Knight: Treasure Trove', 'Switch', 2017, 25, 'Aventura', 'Nintendo'), \
                     ('Dragon Ball Origins', 'DS', 2008, 40, 'Aventura', 'Bandai Namco'),\
                     ('Mystery Detective', 'DS', 2006, 15, 'Detectives', 'Atlus')]
    #     
    # =============================================================================
    crea_games (llista_games)   
    elimina_game('Prueba')
