# -*- coding: utf-8 -*-
"""
Creado Lun Dic 20 18:25:05 2021
hjkgkhg
@author: Pablo
"""

import tkinter as tk
from tkinter import *
from tkinter import ttk
from collections import Counter
from tkinter import filedialog
       
def navegar():
         file = filedialog.askopenfilename(initialdir='./tkinter/dat',
         filetypes=(("dat","*.dat"),("all files","*.*")),
         title= "Selecciona arxiu")
         fichero = open(file, 'r')
         content= fichero.read()
         texto.delete(1.0, 'end')
         texto.insert('insert',content)
         fichero.close
        
def calcular():
    
        cadena =  texto.get(1.0, 'end')  

        fich = open("./dat/python.txt", "r", encoding="UTF-8")
        cadena = fich.read()
        fich.close()
        cadena = cadena.lower()
        cadena = cadena.replace('.',' ')                
      
        palabras = cadena.split(" ") 
        
        print ("hay : ",len(palabras))
        cont = f"Total de palabras {len(palabras)}\n"
        c = set(palabras)      
        difers = list(c)              
        print ("hay diferentes:",len(difers))          
        cont2 = f"Total de palabras diferentes {len(difers)} \n"
        resultado.insert('insert', cont)
        resultado.insert('insert', cont2)
        
        d = Counter(palabras)
        
        
        max_freq = d.values()
        print(max_freq)
        if len(max_freq) > 0 :            
            max_freq = sorted(max_freq, reverse=True)[0]
            #print(maxis)
            cont3= ("El resultado era:\n")
            for i in range (max_freq, 2, -1):
                for j in d :
                    if d[j] == i :
                        cont3+= f"{j},{d[j]}\n"
        
        resultado.delete(1.0, 'end')                
        resultado.insert('insert',cont3 )
# Configuración de la raíz
       
root = Tk()
root.title("prj_texto")

texto = StringVar()
nombre=StringVar()
x=IntVar()
contenido=StringVar()


label = Label(root,justify="center",text="Texto:").pack()
texto = Text(root, height= 10 , width=80)
texto.pack()

label = Label(root,justify="left", text="Archivo a descartar:").pack()
Entry(root, justify="center", state="normal").pack()
Button(root, text="Navegar",justify="right", command=navegar).pack()


label = Label(root,justify="left", text="Descartar palabras de menos de x letras").pack()
Entry(root, justify="center", state="normal").pack()

Button(root, text="Calcular", command=calcular).pack()
label = Label(root,justify="center", text="Resultado").pack()
resultado = Text(root, width= 80, height= 10)
resultado.pack()

# Finalmente bucle de la aplicación
root.mainloop()