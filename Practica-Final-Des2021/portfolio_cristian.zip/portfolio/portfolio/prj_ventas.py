# Practica P04 Avanzado - Selectores

# CALCULO DE VENTAS
# Crea una ventana que lea las ventas de una empresa y permita escoger los
# datos que se mostrarán y el tipo de gráfico.
# Archivo de entrada : caja de texto + botón de selector de fichero
# ver diapos 20 y 24)
# Agrupar por : Centro / TipoCliente / Distrito : Radio Button :
# Desglose por meses o Total anual : Radio Button :
# Número de Factura y/o Total Ventas : Check Button.
# Calcular Botón
# Resultado : Caja de Texto
# Gráfico de Líneas o Barras o Tarta : Botones

from tkinter import *
from tkinter import filedialog
from tkinter import ttk
from pandas import DataFrame
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg


def cargar():
# Para cargar el archivo de ventas tipo csv

    global df
    filename = filedialog.askopenfilename(parent=root, initialdir = "./dat/", title = "Selecciona el Archivo", filetypes = (("csv","*.csv"),("all files","*.*")))
    filerute.set(filename)
    r.set("Archivo Cargado!")
    
    df = pd.read_csv(filename, sep=";", index_col=False)
    print (df)
    
    consola.delete("1.0","end")
    consola.insert(INSERT,df)
    
def selec():
    print(opcion.get())
    

    
def gLineas():
    print(opDes.get())

def gBarras():
    print(opDes.get())
    
def gTarta():
    print(opDes.get())
    
def calcular():
    global df
    print(opDes.get())
    
#     if df == None :
#         r.set("No hay Archivo!")
    
    agrupar_por = opcion.get()   # 1=Centro, 2=TipoCliente , 3 = Distrito
    desglose = opDes.get()  # 4 = total anual ; 5 = por meses
    factura = contarFac.get()   # 0 = no contar facturas , 1 = contar facturas 
    totales = totVentas.get()   # 0 = no contar totales , 1 = contar totales

    columnas = ['anyy']
    operaciones = []

    if agrupar_por == 2 :
        columnas.insert(0,'tipo')
    elif agrupar_por == 3 :
        columnas.insert(0,'c_postal')

    if desglose == 5 :
        columnas.append('mes')

    if factura == True :
        operaciones.append('count')

    if totales == True :
        operaciones.append('sum')

    if len(operaciones) > 0 :
        dfcalc = df.groupby(columnas).agg({'total_fra': operaciones})
        print (dfcalc)
    else :
        print ('No ha seleccionado operaciones')
    
def quit():
    root.destroy()

# Estructura del GUI de Ventas con Grid
root = Tk()
root.title("Ventas")
df = None

cptArch = StringVar() # Carpeta archivo

frame1 = ttk.Frame(root)
root.config(bd=15)
frame1_1 = ttk.Frame(frame1, borderwidth=5, relief="sunken", width=400,height=200)

namelbl = ttk.Label(frame1, text="Ruta del archivo")
desgloselbl = ttk.Label(frame1, text="Desglose por:")
agruparlbl = ttk.Label(frame1, text=" Agrupar por:") 
graficolbl = ttk.Label(frame1, text=" Grafico por:") 


r = StringVar()
filerute = StringVar()

r.set("Resultado")
opcion = IntVar() 
opDes = IntVar() #Opcion desglose

contarFac = BooleanVar()
totVentas = BooleanVar()

contarFac.set(True)
totVentas.set(False)

# texto = Text(root)
# texto.pack()
# texto.config(width=80, height=15, font=("Consolas",12),padx=15, pady=15)



name = ttk.Entry(frame1, state=DISABLED, textvariable = filerute)

one = ttk.Radiobutton(frame1, text="Centro", variable=opcion, value=1, command=selec)
two = ttk.Radiobutton(frame1, text="Tipo de Cliente", variable=opcion, value=2, command=selec)
three = ttk.Radiobutton(frame1, text="Distrito", variable=opcion, value=3, command=selec)

four = ttk.Radiobutton(frame1, text="Meses", variable=opDes, value=4, command=selec)
five = ttk.Radiobutton(frame1, text="Total Anual", variable=opDes, value=5, command=selec)

six = ttk.Checkbutton(frame1, text="Número de Factura", variable=contarFac, onvalue=True, command=selec)
seven = ttk.Checkbutton(frame1, text="Total Ventas", variable=totVentas, onvalue=True, command=selec)

ok = ttk.Button(frame1, text="Cargar", command=cargar)
cancel = ttk.Button(frame1, text="Cerrar", command=quit)

calcular = ttk.Button(frame1, text="Calcular", command=calcular)

lineas = ttk.Button(frame1, text="Lineas", command=gLineas)
barras = ttk.Button(frame1, text="Barras", command=gBarras)
tarta = ttk.Button(frame1, text="Tarta", command=gTarta)

resultado = ttk.Entry(frame1, textvariable = r, state=DISABLED)

consola = Text(width=80, height=15, font=("Consolas",12),padx=15, pady=15, bd=2)

frame1.grid (column=0, row=0)
frame1_1.grid (column=0, row=0, columnspan=3, rowspan=2)
namelbl.grid (column=3, row=0, columnspan=2)
name.grid (column=3, row=1, columnspan=2)

agruparlbl.grid (column=1, row=2)
one.grid (column=0, row=3)
two.grid (column=1, row=3)
three.grid (column=2, row=3)

desgloselbl.grid (column=0, row=4)
four.grid (column=1, row=4)
five.grid (column=2, row=4)

graficolbl.grid (column=1, row=5)
lineas.grid (column=0, row=6)
barras.grid (column=1, row=6)
tarta.grid (column=2, row=6)

ok.grid (column=3, row=3)
cancel.grid (column=4, row=3)

six.grid (column=3, row=4)
seven.grid (column=4, row=4)

calcular.grid (column=3, row=5)
resultado.grid(column=4, row=5)
consola.grid(row=5)
root.mainloop()