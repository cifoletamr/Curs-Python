#  Proyecto de texto

# Realiza un programa que se llame prj_texto.py y que lea el fichero de texto “python.txt” que te pasa el tutor. 
# Pasa el texto a minúsculas, conserva los acentos. Substituye punto por espacio y coma por nada.
# Pide un archivo de palabras a descartar, y además Descarta las palabras de menos de 4 letras.
# Una vez descartado todo, responde a las siguientes preguntas :
# ¿Cuantas palabras tiene el texto ahora ? ____      ¿ Y palabras diferentes?

# Muestra la tabla de frecuencias de las palabras que aparecen más de una vez. Ordena por valor de la frecuencia en descendente. Completa el fichero de descarte hasta que el resultado sea significativo.

#-------------- Proyecto de texto
from tkinter import *
from collections import Counter
from tkinter import filedialog

def cargar():
# Para cargar el archivo de palabras que se van a descartar

    filename = filedialog.askopenfilename(parent=root, initialdir = "./dat/", title = "Selecciona el Archivo", filetypes = (("dat","*.dat"),("all files","*.*")))
    cptArch.set(filename)
    
    file = open(filename, "r", encoding="UTF-8")
    descartar = file.read()
    descartar.lower()
    descartar = descartar.split("\n")
    
#     print(descartar)
#     descartar.remove("")
    file.close()
    
# Ahora que tenemos la lista de palabras a descartar las tomamos y las eliminamos del texto

# Convierte el texto que esta en la variable f en una lista
    palabras = f.split(" ")

    for p in list(palabras):
        if p in descartar:
            palabras.remove(p)
#             print(palabras)
            
    palabras = " ".join(palabras)
    texto.delete("1.0","end")

    texto.insert(INSERT,palabras)
    r.set("Las palabras han sido cargadas y eliminadas del texto")

def calcular():
        palabras = f.split(" ")
        
        numPermitidos="1234"
        
        if numPermitidos.find(motsNum.get()) == -1 :
            
            r.set("Ingrese # del 1 al 4")
        else:
            
            # Depura : palabras solo de > 3 letras y no en descartar
            palasin = [x for x in palabras if len(x) > int(motsNum.get()) ]

            texto.delete("1.0","end")

            texto.insert(INSERT,palasin)
            
            
            r.set("Las palabras de "+motsNum.get()+" letras han sido eliminadas del texto")

            # Cuantas palabras hay
            consola.delete("1.0","end")
            consola.insert(INSERT,"hay : "+ str(len(palasin))+"\n")  

            # convierte lista en conjunto
            # y pasa el conjunto a otra lista palabras pero ya diferentes
            # Cuantas palabras diferentes hay
            c = set(palasin)      
            difers = list(c)

            consola.insert(INSERT,"hay diferentes:"+ str(len(difers))+"\n") 


            d = Counter(palasin)

            max_freq = d.values()

            consola.insert(INSERT,"La Maxima Frecuencia es:"+ str(max_freq)+"\n")       

            max_freq = sorted(max_freq, reverse=True)[0]

            for i in range (max_freq, 2, -1):
                for j in d :
                    if d[j] == i :
                        consola.insert(INSERT,str(j)+","+ str(d[j])+"\n")




# Estructura del GUI del analisis de texto
root = Tk()
root.config(bd=15)  # borde exterior de 15 píxeles, queda mejor
root.title("Analisis de Texto") 
# root.geometry('250x150')

# Cuatro StringVar para manejar los números y el resultado
motsNo = StringVar()
motsNum = StringVar()
cptArch = StringVar() # Carpeta archivo
r = StringVar()
motsNum.set("3")
Label(root, text="Texto").pack()

texto = Text(root)
texto.pack()
texto.config(width=80, height=15, font=("Consolas",12),padx=15, pady=15)

consola = Text(root)
consola.pack(side="bottom")
texto.config(width=80, height=15, font=("Consolas",12),padx=15, pady=15)

f = open("dat\python.txt", "r", encoding = "utf8")

f= f.read().lower()

f= f.replace("."," ")

f= f.replace(",","")

texto.insert(INSERT,f)


Label(root,justify=CENTER, text="\nPalabras a descartar").pack(side="left")
Entry(root,justify=CENTER, state=DISABLED ,text="cargar", textvariable=cptArch).pack(side="left")
Button(root,justify=CENTER, text="cargar", command=cargar).pack(side="left")

Label(root, text="\n").pack()  # Separador


Label(root, justify=CENTER, text="\nEliminar palabras de este número de letras").pack(side="left")
Entry(root, justify=CENTER, textvariable=motsNum).pack(side="left")
Button(root,justify=CENTER,text="Calcular", command=calcular).pack(side="left")



Label(root, text="\nResultado").pack(side="bottom")
Entry(root, justify=CENTER, state=DISABLED, textvariable=r, width=80 ).pack(side="bottom")
 

root.mainloop()
