from setuptools import setup

setup(name="Portfolio",                 # Nombre
    version="0.1",                      # Versión de desarrollo
    description="Menu con acceso a diferentes programas",    # Descripción del funcionamiento
    author="Federico Talato",              # Nombre del autor
    author_email='federico.talato@gmail.com',      # Email del autor
    license="GPL",                      # Licencia: MIT, GPL, GPL 2.0...
    url="",           # Página oficial (si la hay)
    packages=['portfolio'],
)