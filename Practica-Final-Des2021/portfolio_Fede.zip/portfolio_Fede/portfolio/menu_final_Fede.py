# -*- coding: utf-8 -*-
# per fare un menu iniziale dove selezionare programmi della stessa cartella

"""
Created on Mon Dec 20 17:53:34 2021

@author: Fede

Descripción: Crear un menú con las diferentes opciones para elegir un programa
"""

import easygui
import form_jocs

opciones = ['Análisis Texto', 'Ventas Pandas', 'BD Jocs', 'Salir']
opcion_texto = ""

while opcion_texto != 'Salir' :
    opcion_texto = easygui.buttonbox('Seleccione ocpión', 'Practica de Portfolio', opciones)
    opcion = opciones.index(opcion_texto)
    print(opcion_texto, opcion)
    if opcion == 0 :
        import prj_texto_final_Fede
    elif opcion == 1 :
        import prj_ventas_final_Fede
    elif opcion == 2 :
        form_jocs.principal()
