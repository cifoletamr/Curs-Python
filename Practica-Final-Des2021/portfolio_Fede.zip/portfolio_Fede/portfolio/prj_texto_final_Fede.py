#!/usr/bin/env python
# coding: utf-8

"""
Created on Mon Dec 20 17:53:34 2021

@author: Fede

Descripción: Elegir un fichero con texto para poder poder lcalcular las palabras
"""


# Botones para calcular
# Frame entry per chiedere dati

from tkinter import *
from tkinter import filedialog as FileDialog
from io import open

ruta = ""

def abrir():
    """
    Función para abrir el fichero que contiene el texto por analizar
    """
    global ruta
    
    ruta = FileDialog.askopenfilename(
        initialdir='.', 
        filetypes=(("Ficheros de texto", "*.txt"),),
        title="Abrir un fichero de texto")

    if ruta != "":
        fichero = open(ruta, 'r', encoding="UTF-8")
        contenido = fichero.read()
        texto_intro.delete(1.0,'end')
        texto_intro.insert('insert', contenido)
        fichero.close()
        root.title(ruta + " - Mi editor")

def calcular() :
    """ Funcion para hacer seleccion de las palabras que interesan en el texto
    (crear condiciones para que sean todas separadas, 
     quitar las que están en un determinado fichero,
     quitar las que sean de un numero de letras menor de un valor,
     contar las palabras restantes,
     contar las repeticiones de cada palabra)
    """
        
    # minusculas
    texto = texto_intro.get(1.0,'end-1c')

    # substituir puntos y comas
    texto = texto.replace("."," ")
    texto = texto.replace(",","")

    # crear lista con palabras
    palabras = texto.split(" ")

    # Quitar las palabras del fichero
    fich = open("./dat/descartar.dat", "r", encoding="UTF-8")
    descartar = fich.read()
    descartar = descartar.split("\n")
    descartar.remove("")
    fich.close()
    
    palab_selec = []
    for i in palabras :
        if i not in descartar :
            palab_selec.append(i)
    

    # seleccionar palabras de menos de x letras
    escogidas = []
    for i in palab_selec :
        if len(i) > num_letras.get() :
            escogidas.append(i)

    # numero palabras seleccionadas en el texto (también con repeticiones)
    num_palab = len(escogidas)

    # quitar repeticiones de la lista de palabras
    escogidas_norep = []
    for i in escogidas :
        if i not in escogidas_norep :
            escogidas_norep.append(i)

    #  numero palabras seleccionadas no repetidas
    num_palab_norep = len(escogidas_norep)

    # Muestra el número de veces que aparece cada una de las palabras (utilizada más de 2 veces)
    palab_cont = {}
    t = ""
    for i in escogidas_norep :
        if texto.count(i) > 2 :
            t += f"{i} :\t {texto.count(i)}\n"

    resultado.delete(1.0, "end")
    resultado.insert('insert', f"Número de palabras seleccionadas en el texto:\t{num_palab}\n")
    resultado.insert('insert', f"Número de palabras diferentes:\t{num_palab_norep}\n")
    resultado.insert('insert', t)
    


# Estructura del formulario
root = Tk()
root.config(bd=15)  # borde exterior de 15 píxeles, queda mejor

# Tres StringVar para manejar los números y el resultado
texto_selecc = StringVar()
num_letras = IntVar()
resultado = StringVar()

# Los frames (texto, donde sacar palabras vetadas, numero letras, resultado)
Label(root, text="\nTexto (max 800 caracteres)").pack()
texto_intro = Text(root)
texto_intro.pack()
texto_intro.config(width=80, height=10, font=("Consolas",12), padx=15, pady=15, selectbackground="red")
# Entry(root, justify=CENTER, textvariable=texto_selecc).pack()


Button(root, text="Navegar", command=abrir).pack()


Label(root, text="Descartar palabras con un numero de letras menor de: ").pack()
Entry(root, justify=CENTER, textvariable = num_letras).pack()

Label(root).pack() # Separador

Button(root, text="Calcular", command=calcular).pack()

Label(root, text="\nResultado").pack()
resultado = Text(root)
resultado.pack()


root.mainloop()


# In[ ]:




