#!/usr/bin/env python
# coding: utf-8
"""
Created on Mon Dec 20 17:53:34 2021

@author: Fede

Descripción: Elegir un fichero csv con datos de ventas para 
seleccionar los datos que interesan y imprimirlos con el gráfico que se quiere
"""

import pandas as pd
import sys
from tkinter import *
from tkinter import filedialog


def calcular() :
    """
    Función para poner en pantalla la seleccion de datos que se indicó
    """
    global filename
    global dfcalc
    df = pd.read_csv(filename, sep=";", index_col=False)
    columnas = []
    operaciones = []
    
    if grupo.get() == 0 :
        columnas.insert(0,'centro')
    elif grupo.get() == 1 :
        columnas.insert(0,'tipo')
    elif grupo.get() == 2 :
        columnas.insert(0,'c_postal')

    if desglose.get() == True :
        columnas.append('mes')

    if num_fac.get() == 1 :
        operaciones.append('count')

    if tot_vent.get() == 1 :
        operaciones.append('sum')

    if len(operaciones) > 0 :
        dfcalc = df.groupby(columnas).agg({'total_fra': operaciones})
        resultado.delete(1.0, "end")
        resultado.insert('insert', dfcalc)
    else :
        print ('No ha seleccionado operaciones')
        
    
def navegar() :
    """
    Función para encontrar y abrir la lista de datos por analizar
    """
    global filename
    filename = filedialog.askopenfilename(parent=root, 
                                              title ="Selecciona ",
                                              initialdir = "./dat/", 
                                              filetypes = (("csv","*.csv"),("allfiles","*.*")))

    

def graf_barras() :
    """Funcion para crear un grafico de barras con los datos elegidos"""
    global dfcalc
    dfcalc.plot(kind = "bar")

def graf_tarta() :
    """Funcion para crear un grafico de tarta con los datos elegidos"""
    global dfcalc
    dfcalc.plot(kind = "pie", y = "total_fra")
    
def graf_lineas() :
    """Funcion para crear un grafico de lineas con los datos elegidos"""
    global dfcalc 
    dfcalc.plot()
    
    
#------------------------------------------ Programa principal
root = Tk()
root.title("Visualizar ventas")
root.geometry('520x900')
root.config(bd=15)

grupo = IntVar()
desglose = BooleanVar()
num_fac = IntVar() # 1 si, 0 no
tot_vent = IntVar() # 1 si, 0 no
texto = StringVar()

Button(root, text="Navegar", command=navegar).pack()

Label(root, text = "Agrupar por: ").pack()
Radiobutton(root, text="Centro", variable=grupo, value=0).pack()
Radiobutton(root, text="Tipo de cliente", variable=grupo, value=1).pack()
Radiobutton(root, text="Distrito", variable=grupo, value=2).pack()

Label(root, text = "Quiere desglosar por meses?").pack()
Radiobutton(root, text="Sí", variable=desglose, value=True).pack()
Radiobutton(root, text="No", variable=desglose, value=False).pack()

Label(root, text = "Quiere obtener estos datos adicionales?").pack()
Checkbutton(root, text="Numero de factura", variable=num_fac, onvalue=1, offvalue=0).pack()
Checkbutton(root, text="Total ventas",variable=tot_vent, onvalue=1, offvalue=0).pack()

Label(root).pack() # Separador

Button(root, text="Calcular", command=calcular).pack()

Label(root, text="\nResultado").pack()
resultado = Text(root)
resultado.pack()

Label(root, text="Elige gráfico: ").pack()
Button(root, text="Barras", command=graf_barras).pack(anchor="center")
Button(root, text="Tarta", command=graf_tarta).pack(anchor="center")
Button(root, text="Lineas", command=graf_lineas).pack(anchor="center")


root.mainloop()


# In[ ]:




