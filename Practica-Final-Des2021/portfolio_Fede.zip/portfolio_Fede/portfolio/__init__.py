# -*- coding: utf-8 -*-
"""
Created on Mon Dec 20 17:53:34 2021

@author: Fede
"""

import menu_final_Fede
import prj_texto_final_Fede
import prj_ventas_final_Fede

help(menu_final_Fede)
help(prj_texto_final_Fede)
help(prj_ventas_final_Fede)