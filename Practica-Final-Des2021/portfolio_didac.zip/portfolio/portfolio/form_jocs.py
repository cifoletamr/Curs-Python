# -*- coding: utf-8 -*-
"""
Name : Mantenimiento de juegos
Created : Tues Oct 5 10:11:52 2021
@author: Alumno
"""

from tkinter import Tk, Frame, StringVar, Label, Entry, DISABLED, Text, INSERT, END
from tkinter import ttk
import  bd_jocs as bd

class Application (ttk.Frame):

    def __init__(self, window):
        super().__init__(window)
        self.win = window
        self.win.title("Gestión de juegos")
        self.win.geometry('1000x600')
        self.win.configure(bg='#98D1F2')
        self.opcio = ""
        
        self.frame1= Frame(self.win)     # Crea un frame para mostrar registros de juegos 
        self.muntar_frame1(self.frame1)  
 
        self.frame2= Frame(self.win)     # Crea un frame para pedir game_title y resto de formulario
        self.muntar_frame2(self.frame2)   

    def muntar_frame1(self, frame1) :
        """ Crea un frame para mostrar registros de juegos
        , los carga de la BBDD a un array y a self.games """
        self.games = []
       
        self.textarea = Text(frame1, width = 350, height=12, padx=5, pady=5 )
        self.textarea.grid(row = 1,column =0)

        frame1.pack(fill="both", side = 'top') 
        self.mostrar_games()

        frameB= Frame(self.win)
        ttk.Button(frameB ,text="Crear ", width=10, command=self.cmd_afegir_game).grid(row=2, column=0)
        ttk.Button(frameB ,text="Esborrar ", width=10, command=self.cmd_esborrar_game).grid(row=2, column=1)
        ttk.Button(frameB ,text="Refrescar ", width=10, command=self.mostrar_games).grid(row=2, column=2)
        frameB.pack(side = 'top') 
        
    def cmd_afegir_game(self):
        self.esborra_caixes()
        self.opcio = "+"        
        self.frame2_visible (True)
        self.frame3_visible (False)

    def cmd_esborrar_game(self):
        self.esborra_caixes()
        self.opcio = "-"
        self.frame2_visible (True)    
        self.frame3_visible (False)     
        
    def muntar_frame2(self, frame2) :  
         self.game_title =StringVar()
         self.msg =StringVar()
                  
         Label(frame2 ,text = "Game Title     ").grid(row = 0,column = 0, pady = 15) 
         
         dd = Entry(frame2, textvariable=self.game_title)
         dd.grid(row = 0,column = 1)
         dd.bind('<Return>', self.tracta_event)
         Entry(self.frame2, textvariable=self.msg, state=DISABLED, width=40).grid(row = 9,column = 0, columnspan=2, pady=5)
    
         self.frame3= Frame(self.win)     # Crea un frame para el formulario
         self.muntar_frame3(self.frame3)   
         
         frame2.config(width=500, height=150, bg="#98D1F2") 
  
    def muntar_frame3(self, frame3) :
         # Crea un frame para el formulario
         # pide datos y aceptar o cancelar    
        frame3.config(width=700,height=250, bg='#98D1F2') 
        frame3.grid_rowconfigure(0, weight=1)

        self.platform =StringVar()
        self.release_year =StringVar()
        self.price =StringVar()
        self.genre =StringVar()
        self.publisher =StringVar()        
        
        # https://www.plus2net.com/python/tkinter-grid.php

        Label(frame3 ,bg='#98D1F2',text = "Plataforma     ").grid(row = 1,column = 0)
        Label(frame3 ,bg='#98D1F2',text = "Any de llançament").grid(row = 2,column = 0)
        Label(frame3 ,bg='#98D1F2',text = "Preu").grid(row = 3,column = 0)
        Label(frame3 ,bg='#98D1F2',text = "Génere  ").grid(row = 4,column = 0)
        Label(frame3 ,bg='#98D1F2',text = "Distribuïdor ").grid(row = 5,column = 0)        

        Entry(frame3, textvariable=self.platform).grid(row = 1,column = 1)
        Entry(frame3, textvariable=self.release_year).grid(row = 2,column = 1)
        Entry(frame3, textvariable=self.price).grid(row = 3,column = 1)
        Entry(frame3, textvariable=self.genre).grid(row = 4,column = 1)
        Entry(frame3, textvariable=self.publisher).grid(row = 5,column = 1)       

        ttk.Button(frame3 ,text="Cancelar", command=self.cmd_cancelar).grid(row=6, column=0)
        ttk.Button(frame3 ,text="Aceptar", command=self.cmd_enviar).grid(row=6, column=1)

    def frame2_visible(self, mode):
        if mode == True :
            self.frame2.pack()
        else :
            self.frame2.pack_forget()         
         
    def frame3_visible(self, mode):
        if mode == True :
            self.frame3.pack()
        else :
         self.frame3.pack_forget()   
        
    def esborra_caixes(self):
        try:
            self.game_title.set("")
            self.platform.set("")
            self.release_year.set("")
            self.price.set("")
            self.genre.set("")
            self.publisher.set("")            
        except Exception as e:
            print("Error: ", e)
        self.frame3_visible(True)
        
    def cmd_enviar(self) :
        try:
            # Creamos una lista con tupla juegos 
            # (id,game_title,platform,release_year,price,genre, publisher)
            game = (self.game_title.get(), self.platform.get(), self.release_year.get(), 
                       self.price.get(), self.genre.get(), self.publisher.get())

            if self.opcio == "+" or self.opcio == "-" :
                if self.opcio == "+" :
                    bd.crea_game (game)
                elif self.opcio == "-" :
                    bd.elimina_game (self.game_title.get())
                print ("Joc enviat ", game)
                self.esborra_caixes()
                self.msg.set( "Dades del joc enviades")
                self.mostrar_games() 
        except Exception as e:
            self.msg.set(e)   
        self.frame3_visible(True)

    def cmd_cancelar(self) :
        try:
            self.esborra_caixes()
            self.frame2_visible(True)
        except Exception as e:
            print("Error: ", e)   
            
    def mostrar_games(self) :
        # Coge los clientes de la bbdd y los monta en el textarea
        # del frame de la zona 1
        self.games = bd.consulta_games()
        cad = " ID \t\t Nom joc\t\t\t Plataforma\t\t Any llançament\t\t Preu\t Génere\t\t Distribuïdor\n" ; 
        uno = "{:3} {:37} {:12} {:11} {:10} {:20} {:15} \n" 
        for l in self.games :
            cad += uno.format(l[0],l[1],l[2],l[3],l[4],l[5],l[6])
        self.textarea.delete('1.0', END)
        self.textarea.insert('1.0', cad)

    def tracta_event(self, event):

        self.mostrar_un_game(self.game_title.get())
        
        if (self.opcio == "-" and self.game_title.get() == ""):
            self.msg.set( "** Error : client no existeix. No elimino **")
        elif (self.opcio == "+" and self.game_title.get() != ""):
            self.msg.set( "** Error : dni ja existeix. No creo **")
        else :
            self.frame3_visible (True)
            self.msg.set("")
        
        self.frame3_visible (True)
        self.msg.set("")        

    def mostrar_un_game(self, game_title) :
        # Agafa les dades d'un client base de dades i els carrega al formulari
        # del frame de la zona 1
        self.esborra_caixes()
        self.game_title.set(game_title) 
        lista = bd.consulta_game(game_title)
        for l in lista :
            self.platform.set(l[2]) 
            self.release_year.set(l[3]) 
            self.price.set(l[4]) 
            self.genre.set(l[5]) 
            self.publisher.set(l[6]) 

def principal ():
    window = Tk()
    app = Application(window)
    app.mainloop()          
#------------------------------------------------- Main
if __name__ == "__main__":
    principal()
    

 
