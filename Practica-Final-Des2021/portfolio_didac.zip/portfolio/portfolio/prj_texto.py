"""
Created on Mon Dec 20 17:33:21 2021
lligeix un text y calcula les paraules descartades
@author: Didac Flamarqiue
"""
# -*- coding: utf-8 -*-

from tkinter import *
from tkinter import ttk
from tkinter import filedialog
import pandas as pd
from collections import Counter
import io

def nav():
    file = filedialog.askopenfilename(
    initialdir = ".tkinter/dat", filetypes = (("dat","*.dat"),("all files","*.*")),
    title = "Selecciona arxiu")
    ficher = open(file, 'r')
    contenido3 = ficher.read()
    texto.delete(1.0, 'end')
    texto.insert('insert', contenido3)
    ficher.close()
    
    


def numero():
    print(palabra.get())

def calcular():
    fich = open("./dat/python.txt", "r", encoding="UTF-8")
    cadena = fich.read()
    fich.close()
    
    
    cadena = texto.get(1.0, 'end')
    print(cadena)
    
    cadena = cadena.lower()
    
    cadena = cadena.replace(".", " ")
    
    fich = open("./dat/descartar.dat", "r", encoding="UTF-8")
    descartar = fich.read()
    descartar = descartar.split("\n")
    descartar.remove("")
    fich.close()
    
    print(cadena)
    palabras = cadena.split(" ")
    print ("hay : ",len(palabras)) 
    # afegir calculs
    contenido =("total paraules", len(palabras))
    c = set(palabras)      
    difers = list(c)              
    print ("hay diferentes:",len(difers))          
    contenido2 =("total paraules diferents", len(difers))
    resultat.insert('insert', contenido)
    resultat.insert('insert', contenido2)
    
    d = Counter(palabras)
    
    max_freq = d.values()
    print(max_freq)
    max_freq = sorted(max_freq, reverse=True)[0]
    #print(maxis)
    contenido4 = (" el resultat es: ")
    for i in range (max_freq, 2, -1):
        for j in d :
            if d[j] == i :
                contenido4 += f"{j}, {d[j]}"
    resultat.insert('insert', contenido4)
    resultat.insert('insert', contenido5)

root = Tk()
palabra = IntVar()

label = Label(root, text="escribe: ")
label .pack()
texto = Text(root)
texto.pack()
texto.config(width=30, height=10, font=("Consolas",12), 
             padx=15, pady=15, selectbackground="blue")

    
Button(root, text="navegar", command=nav).pack() 

label = Label(root, text="minimo de palabras: ")
label .pack(side=LEFT)
entry = Entry(root, textvariable=palabra)
entry.pack()

Button(root, text="num", command=numero).pack() 
Button(root, text="calcular", command=calcular).pack() 

resultat = Text(root)
resultat.pack()
    





root.mainloop()