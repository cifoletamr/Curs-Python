"""
Created on Mon Dec 20 17:33:21 2021
calcula les ventes mensuals y anuals
@author: Didac Flamarqiue
"""
# -*- coding: utf-8 -*-

from tkinter import *
from tkinter import ttk
from tkinter import filedialog
import numpy as np
import pandas as pd

def awa():
    
    filename = filedialog.askopenfilename(parent=root, 
                        initialdir = "./dat/",
                        title = "Selecciona arxiu",
                        filetypes = (("csv","*.csv"),
                        ("all files","*.*")))
    df = pd.read_csv(filename, sep=";")
    pd.set_option('display.max_rows', 500)
    pd.set_option('display.max_columns', 500)
    pd.set_option('display.width', 1000) 
    display(df)
def calcular():
    contenido =("El resultat es: ", df)
    resu.insert('insert', contenido)
def grafic():
    contenido2 =("El resultat es: ", dfgraf)
    resu.insert('insert', contenido2)
    
    
    
    
    
    
root = Tk() 
frame1 = ttk.Frame(root)
frame1_1 = ttk.Frame(frame1, borderwidth=5, relief="sunken", width=200,height=100)
onevar = BooleanVar()
twovar = BooleanVar()
threevar = BooleanVar()
fourvar = BooleanVar()
fivevar = BooleanVar()
sixvar = BooleanVar()
sevenvar = BooleanVar()
onevar.set(True)
twovar.set(False)
threevar.set(True)
radio1 = ttk.Radiobutton(frame1, text="centre", variable=sixvar)
radio2 = ttk.Radiobutton(frame1, text="tipus client", variable=sevenvar)
radio3 = ttk.Radiobutton(frame1, text="districte", variable=threevar)

radio4 = ttk.Radiobutton(frame1, text="per mesos", variable=fourvar)
radio5 = ttk.Radiobutton(frame1, text="anual", variable=fivevar)
    
one = ttk.Checkbutton(frame1, text="Nuero Facturas", variable=onevar, onvalue=True)
two = ttk.Checkbutton(frame1, text="Total Ventas", variable=twovar, onvalue=True)
ok = ttk.Button(frame1, text="calcular", command=calcular)
cancel = ttk.Button(frame1, text="grafico", command=grafic)
resu = Text(frame1)

frame1.grid (column=0, row=0)
frame1_1.grid (column=0, row=0, columnspan=3, rowspan=2)
one.grid (column=0, row=3)
two.grid (column=1, row=3)
radio1.grid (column=2, row=3)
radio2.grid (column=3, row=3)
radio3.grid (column=4, row=3)
radio4.grid (column=5, row=3)
radio5.grid (column=6, row=3)
ok.grid (column=7, row=3)
cancel.grid (column=8, row=3)
resu.grid (column=0, row=6, rowspan=2, columnspan=3)

df = pd.read_csv("./dat/datos_fras.csv", sep=";", index_col=False)
print (df)   

dfNov = df[(df['anyy'] == 2021 )]
dfgraf = dfNov.groupby('mes')['total_fra'].count()
print(dfgraf)
dfgraf.plot()      
  
    
    
    
    
root.mainloop()