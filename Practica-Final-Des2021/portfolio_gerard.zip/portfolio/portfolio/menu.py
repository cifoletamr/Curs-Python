# -*- coding: utf-8 -*-
"""
Created on Mon Dec 20 17:46:30 2021

@author: Alumne_tarda2
"""

# -*- coding: utf-8 -*-
import easygui
import form_jocs

opciones = ['texto', 'ventas', "joc", 'Salir']
opcion_texto = ""
while opcion_texto != 'Salir' :
    opcion_texto = easygui.buttonbox('Caja de texto', 
                                     'Practica de Portfolio', opciones)
    opcion = opciones.index(opcion_texto) 
    print(opcion_texto, opcion) 
    if opcion == 0 :
        import prj_texto
    elif opcion == 1 :
        import prj_ventas
    elif opcion == 2 :
        form_jocs.main()             