
# -*- coding: utf-8 -*-

"""
Created on Tue Dec 21 16:29:37 2021

@author: Gerard BOnet LLeixà

# EXERCICI INACABAT. HE POGUT CREAR LA ESTRUCTURA DEL WIDGET, CREAR LES FUNCIONS, PERO NO HE ACABAT PER TEPMPS A LA PART DE
# EXTREURE LA INFORMACIÓ Y AICÍ COM TOT EL QUE TE A VEURE AMB LES GRÀFIQUES
# el principal problema que he trobat es que la vairable df no la he conseguit mantenir estable el DF. Es ha dir, un cop 
# asignat el Data Frame no es mante com a variable 
# per exepmle a la funcio abrir () s´agafa el DF
# la operació suma es defineix com 
"""
   
#def   suma ():
 #   abrir()
   # df6 = df [[ "total_fra"]]
    #total= df6. sum()
    
# després d´agafar el archiu em surt el misssatge d´error : NameError: name 'df' is not defined

# 0. importar  todas las necesidades del sistema   
from collections import Counter
from tkinter import *
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from io import open
from tkinter import filedialog
from tkinter import messagebox as MessageBox


# definición de funciones
# a.funcion para abrir y pegar archivo en texto
def abrir():
    global ruta
    ruta = filedialog.askopenfilename(
        initialdir='.', 
        filetypes=(("bases de datos", "*.csv"),),
        title="Abrir un fichero de texto")
    if ruta != "":
        fichero = open(ruta, "r", encoding="UTF-8" )
        df = pd.read_csv(fichero, sep= ";")
        
        
        
        
def centro():
    abrir()
    df = df [["centro", 'total_fra']]
    df2 =df.groupby("centro")['total_fra'].sum()
    texto.insert("insert", df2.to_string())
    
def tipo():
    abrir()
    df = df [["tipo", 'total_fra']]
    df3 =df.groupby("tipo")['total_fra'].sum()
    texto.insert("insert", df3.to_string())
    
def c_postal():
    abrir()
    df = df [["c_postal", "total_fra"]]
    df4 =df.groupby("c_postal")['total_fra'].sum()
    texto.insert("insert", df4.to_string())
    
def mes():
    abrir()
    df = df [["mes","anyy", "total_fra"]]
    df5 =df.groupby("mes")['total_fra'].sum()
    texto.insert("insert", df5.to_string())
    
def anyy():
    abrir()
    df = df [["anyy", "total_fra"]]
    df6 =df.groupby("anyy")['total_fra'].sum()
    texto.insert("insert", df6.to_string())
def   suma ():
    abrir()
    df6 = df [[ "total_fra"]]
    total= df6. sum()
    
    texto.insert("insert", total)
  

def calcular():
    if opcion ==1 : 
        centro()
    if opcion ==2 :
        tipo()
    if opcion ==3 :
        c_postal()
    if ocion ==4:
        mes()
    if opcion ==5 :
        anyy()
        
#estructura de tkinter. 

root = Tk()
root.title( "Bases de datos")

Button(root, text="Selecciona archivo", command=abrir).pack() 

opcion = IntVar()

Label(root).pack() # Separador
label = Label(root,text="Escoge una opción para agrupar por: ")
label.pack()

Radiobutton(root, text="Centro", variable=opcion, 
            value=1).pack()
Radiobutton(root, text="TipoCliente ", variable=opcion,
            value=2).pack()
Radiobutton(root, text="Distrito", variable=opcion, 
            value=3).pack()



Label(root).pack() # Separador
label = Label(root,text="Escoge una opción para desglosar por: ")
label.pack()

Radiobutton(root, text="meses", variable=opcion, 
            value=4).pack()
Radiobutton(root, text="total anual ", variable=opcion,
            value=5).pack()

Label(root).pack() # Separador
label = Label(root,text="Facturación total ")
label.pack()


Button(root, text="Sumar", command=suma).pack()


texto = Text(root)
texto.pack()

opcion2 = IntVar()
Label(root).pack() # Separador
label = Label(root,text="Escoge un tipo de gráfico: ")
label.pack()


Radiobutton(root, text="barras", variable=opcion2, 
            value=1).pack()
Radiobutton(root, text="lineas ", variable=opcion2,
            value=2).pack()
Radiobutton(root, text="tarta", variable=opcion2, 
            value=3).pack()


root.mainloop()

