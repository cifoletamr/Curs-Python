# -*- coding: utf-8 -*-
"""
Created on Tue Dec 21 16:29:37 2021

@author: Alumne_tarda2

# 0. importar  todas las necesidades del sistema
"""



from collections import Counter
from tkinter import *
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from io import open
from tkinter import filedialog
from tkinter import messagebox as MessageBox


# definición de funciones
# a.funcion para abrir y pegar archivo en texto
def abrir():
    global ruta
    ruta = filedialog.askopenfilename(
        initialdir='.', 
        filetypes=(("Ficheros de texto", "*.txt"),),
        title="Abrir un fichero de texto")
    if ruta != "":
        fichero = open(ruta, 'r', encoding="UTF-8")
        contenido = fichero.read()
        texto.delete(1.0,'end')
        texto.insert('insert', contenido)

# b. funcion para abrir y pegar archivo en textofichero.close()
def descartar():
    pasalin=[]
    global ruta
    ruta = filedialog.askopenfilename(
        initialdir='.', 
        filetypes=(("Ficheros de texto", "*.txt"),),
        title="Abrir un fichero de texto")
    if ruta != "":
        fichero = open(ruta, 'r', encoding="UTF-8")
        descartar = fichero.read()
        texto.delete(1.0,'end')

        fichero.close()
        
    descartar = descartar.replace( "\n", " ")
    descartar = descartar.replace( ".", " ")
    descartar = descartar.replace( ",", " ")
    descartar = descartar.replace( "﻿", " ")
    descartar = descartar.replace( ":", " ")
       
    descartar = descartar.replace( ":", " ")
    palabras = descartar.split(" ") 
    for k in palabras : 
        if len(k) >= n1.get(): 
            pasalin.append(k)  
    
    Strpasalin= " ".join(pasalin)
    desc = Strpasalin
    texto.insert('insert', desc)   
    
# c. funcion calcula 
def calcular():
    pasalin=[]
    ruta = filedialog.askopenfilename(
        initialdir='.', 
        filetypes=(("Ficheros de texto", "*.txt"),),
        title="Abrir un fichero de texto")
    if ruta != "":
        fichero = open(ruta, 'r', encoding="UTF-8")
        descartar = fichero.read()
        texto.delete(1.0,'end')
        
        fichero.close()
        
    descartar = descartar.replace( "\n", " ")
    descartar = descartar.replace( ".", " ")
    descartar = descartar.replace( ",", " ")
    descartar = descartar.replace( "﻿", " ")
    descartar = descartar.replace( ":", " ")
       
    descartar = descartar.replace( ":", " ")
    mytable = descartar.maketrans( "AEIOUÁÉÍÓÚ", "aeiouáéíóú")
    descartar2= descartar.translate(mytable)
    palabras = descartar2.split(" ") 
    for k in palabras : 
        if len(k) >= n1.get(): 
            pasalin.append(k)  
 # elinimacion de duplicados   
    lista_no_repetida = set(pasalin)      
    diferentes = list(lista_no_repetida)   
    
    numpalabras= str( len( pasalin))
    numdiferentes= str( len (diferentes))
    
    txt1 = " hay un total de " + numpalabras + " palabras\n"
    txt1 += " hay un total de " + numdiferentes + " palabras diferentes\n"
    print (txt1)
    

    texto2.insert('insert', txt1)
    
    txt2 = ""
    for p in diferentes :
        
        if pasalin.count(p) >= 3:
            txt2 = p + "\t" + str(pasalin.count(p))+ "\n"
            texto2.insert('insert', txt2)
            print (txt2)    
    

    

    
# 1.creación de la caja de texto de 800 caracteres. 
root = Tk()
root.title( "Manipulación de archivos")

texto = Text(root)
texto.config(width=80, height=10)
texto.pack()

n1 = IntVar()
n2 = StringVar()
n3 = StringVar()
n4= StringVar()
#2 botón de selección de archivo. 
ruta = ""

        

Label(root).pack() # Separador

Button(root, text="Selecciona archivo", command=abrir).pack()   

# 3 boton para eliminar palabras de menos de x letras 

Label(root).pack() # Separador
Label(root, text="Elimina las palabras de menos de X letras, selecciona X").pack(side="left"), 

Entry(root, textvariable=n1).pack()


Button(root, text="descartar palabras", command=descartar).pack() 

Button(root, text="Calcular", command=calcular).pack() 

texto2 = Text(root)
texto2.config(width=80, height=10 )
texto2.pack()




root.mainloop()