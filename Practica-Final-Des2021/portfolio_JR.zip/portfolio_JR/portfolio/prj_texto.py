# -*- coding: utf-8 -*-
"""
Created on Wed Dec 15 19:35:43 2021

@author: JR

Programa para el analisis de un texto pegado en la ventana de entrada.
Para el analisis elimina del texto las palabras facilitadas en un fichero
al efecto, asi como las palabras de longitud inferior a la longitud entrada
por pantalla

El analisis devuelve el numero total de palabras, palabras diferentes y 
numero de palabras de mayor longitud ordenadas por numero de apariciones
decreciente de las mismas.

"""

from tkinter import *
from tkinter import filedialog as FileDialog
from io import open
from collections import Counter

def finalizar():
    ''' Funcion para finalizar la ejecucion de forma ordenada ''' 

    root.destroy()

def lee_fichero():
    ''' Lee el fichero con las palabras a descartar y añade el boton
    de ejecucion una vez se dispone del fichero para eliminar errores
    en tiempo de ejecucion '''

    global descartar

    filename = FileDialog.askopenfilename(parent=root,
        initialdir = './dat/',
        filetypes = (('dat','*.dat'),('all files','*.*')))
#    filename = './dat/descartar.dat' -------- fichero asignado directamente para pruebas

    fich = open(filename, "r", encoding="UTF-8")
    descartar = fich.read()
    descartar = descartar.split("\n")
    descartar.remove('')
    fich.close()
    Button(root, text = 'Calcular', command=calcular).grid(row=20, column=0)

def tratar_cadena(contenido):
    ''' Esta funcion "limpia" la cadena leida desde la pantalla, convirtiendola
    a minusculas, eliminando las comas y sustituyendo los puntos por espacios'''
    resultado = contenido
    resultado = resultado.lower()
    resultado = resultado.replace(',','')
    resultado = resultado.replace('.',' ')
    
    return resultado
    
    
def calcular():
    ''' Esta funcion reliza todas las operaciones necesarias para devolver los
    resultados descritos en el objetivo del programa'''
    
    global lonmax
    global descartar
    contenido=texto.get(1.0,'end')
    mitexto = tratar_cadena(contenido)

# Convierte el texto en una lista
    palabras = mitexto.split(" ") 
    
# Depura : palabras solo de mas de lonmax letras y no en descartar
    palasin = [x for x in palabras if len(x) > lonmax.get() and x not in descartar]
#   
# Limpia ventana de salida
    resultado.delete(1.0,'end')
    textosalida=''
    
# Cuantas palabras hay
    textosalida +='hay : ' + str(len(palasin)) + '\n'

# convierte lista en conjunto y pasa el conjunto a otra lista palabras pero
#ya diferentes. Cuantas palabras diferentes hay
    c = set(palasin)      
    difers = list(c)              
    textosalida +="hay diferentes : "+str(len(difers)) + '\n \n'
    
    d = Counter(palasin)
    
    max_freq = d.values()
    max_freq = sorted(max_freq, reverse=True)[0]
    for i in range (max_freq, 2, -1):
        for j in d :
            if d[j] == i :
                textosalida +=j +'  '+str(d[j])+ '\n'
                
    resultado.insert('insert', textosalida)

                


# -------------------------------------------------------------------- Inicio
root = Tk()

root.geometry('700x600')

texto = Text(root)
texto.grid(row=1, column=0)
texto.config(width=80, height=10)

resultado = Text(root)
resultado.grid(row=15, column=0)
resultado.config(width=80, height=15)
Label(root, text="RESULTADO").grid(row=5, column=0)


global lonmax
global descartar
lonmax = IntVar()

Button(root, text = 'Selecciona fichero descartes', command=lee_fichero).grid(row=2, column=0)
Label(text="Descartar palabras de menos de .... letras").grid(row=3, column=0)
Entry(root, textvariable=lonmax).grid(row=4, column=0)
Button(root, text = 'Salir', command=finalizar).grid(row=20, column=3)

root.mainloop()