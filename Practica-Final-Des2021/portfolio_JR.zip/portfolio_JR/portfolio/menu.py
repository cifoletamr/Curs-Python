# -*- coding: utf-8 -*-

import easygui
import form_jocs as fj

opciones = ['Análisis Texto', 'Ventas Pandas', 'BD Jocs', 'Sudoku', 'Salir']
opcion_texto = ""

while opcion_texto != 'Salir' :
    opcion_texto = easygui.buttonbox('Selecciona opción ', 
                          'Practica de Portfolio', opciones)
    
    opcion = opciones.index(opcion_texto) 
    print(opcion_texto, opcion) 
    if opcion == 0 :
        import prj_texto
    elif opcion == 1 :
        import prj_ventas
    elif opcion == 2 :
        fj.principal()
    elif opcion == 3 :
        import sudoku