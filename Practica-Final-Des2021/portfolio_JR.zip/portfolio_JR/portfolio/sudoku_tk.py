# -*- coding: utf-8 -*-
"""
Created on Mon Dec 20 17:28:05 2021

@author: Alumne_tarda2
"""
from tkinter import *


def puzzle(a):
    cadena = '\n' + '   '  
    for i in range(M):
        for j in range(M):
            print(a[i][j],end = " ")
            cadena += f'{a[i][j]} '
        print()
        cadena += '\n'+'   '   
#    print(cadena)
    resultado.insert('insert', cadena)

def solve(grid, row, col, num):
    for x in range(9):
        if grid[row][x] == num:
            return False
             
    for x in range(9):
        if grid[x][col] == num:
            return False
 
 
    startRow = row - row % 3
    startCol = col - col % 3
    for i in range(3):
        for j in range(3):
            if grid[i + startRow][j + startCol] == num:
                return False
    return True
 
def Suduko(grid, row, col):
 
    if (row == M - 1 and col == M):
        return True
    if col == M:
        row += 1
        col = 0
    if grid[row][col] > 0:
        return Suduko(grid, row, col + 1)
    for num in range(1, M + 1, 1): 
     
        if solve(grid, row, col, num):
         
            grid[row][col] = num
            if Suduko(grid, row, col + 1):
                return True
        grid[row][col] = 0
    return False

# ---------------------------------------------------------- Inicio de programa
'''0 means the cells where no value is assigned'''

root = Tk()

root.geometry('190x190')

resultado = Text(root)
resultado.grid(row=9, column=0)
resultado.config(width=80, height=15)
Label(root, text="RESULTADO").grid(row=5, column=0)

M = 9
    
 
grid = [[2, 5, 0, 0, 3, 0, 9, 0, 1],
        [0, 1, 0, 0, 0, 4, 0, 0, 0],
        [4, 0, 7, 0, 0, 0, 2, 0, 8],
        [0, 0, 5, 2, 0, 0, 0, 0, 0],
        [0, 0, 0, 0, 9, 8, 1, 0, 0],
        [0, 4, 0, 0, 0, 3, 0, 0, 0],
        [0, 0, 0, 3, 6, 0, 0, 7, 2],
        [0, 7, 0, 0, 0, 0, 0, 0, 3],
        [9, 0, 3, 0, 0, 0, 6, 0, 4]]
     
    
    
if (Suduko(grid, 0, 0)):
    puzzle(grid)
else:
    print("Solution does not exist:(")
        
    
root.mainloop()
    
    