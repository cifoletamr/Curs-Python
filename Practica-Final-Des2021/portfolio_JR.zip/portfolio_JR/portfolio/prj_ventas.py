# -*- coding: utf-8 -*-
"""
Created on Wed Dec 15 19:38:29 2021

@author: Alumne_tarda2
"""

import pandas as pd
import plotly.express as px
import numpy as np
from tkinter import *
from tkinter import filedialog as FileDialog


def selec():
    texto = "Informe "
    if agrupacion.get() == 0 :
        texto+= 'agrupado por centro /'
    if agrupacion.get() == 1 :
        texto+= 'agrupado por TipoCliente /'
    if agrupacion.get() == 2 :
        texto+= 'agrupado por Distrito /'
    
    if tipodesglose.get() == 1 :
        texto+= 'desglose por mes /'
    else:
        texto+= 'total anual /'
        
    if numfactura.get() == 1 :
        texto+= 'por numero factura /'
    else:
        texto+= 'no numero factura /'
        
    if totalventas.get() == 1 :
        texto+= 'por totalventas /'
    else:
        texto+= 'no totalventas /'

def lee_fichero():
    global df

    filename = FileDialog.askopenfilename(parent=root,
        initialdir = "./dat/",
        filetypes = (("csv","*.csv"),("all files","*.*")))
#    filename = './dat/datos_fras.csv'
    label = Label(root, text=filename)
    label.grid(row=1, column=2)
    df = pd.read_csv(filename, sep=";",index_col=False)
    pd.set_option('display.max_rows', 500)
    pd.set_option('display.max_columns', 500)
    pd.set_option('display.width', 1000)
    Button(root, text = 'Calcular', command=calcular).grid(row=5, column=1)
    
def calcular():
    global df
    
    selec()
    
    columnas = ['anyy']
    operaciones = []

    agrupar_por = agrupacion.get()
    desglose = tipodesglose.get()
    factura = numfactura.get()
    totales = totalventas.get()

    if agrupar_por == 1 :
        columnas.insert(0,'tipo')
    elif agrupar_por == 2 :
        columnas.insert(0,'c_postal')

    if desglose == 1 :
        columnas.append('mes')

    if factura == 1 :
        operaciones.append('count')

    if totales == 1 :
        operaciones.append('sum')

    if len(operaciones) > 0 :
        dfcalc = df.groupby(columnas).agg({'total_fra': operaciones})
        print (dfcalc)
        dfcalc.plot()  
    else :
        print ('No ha seleccionado operaciones')
    
def finalizar():
    root.destroy()

# ------------------------------------------------------------------------------ Inicio
root = Tk()
root.geometry('1000x300')
root.config(bd=15)

agrupacion = IntVar()
tipodesglose = IntVar()
numfactura = IntVar()
totalventas = IntVar()

Button(root, text = 'Selecciona fichero de entrada', command=lee_fichero).grid(row=1, column=0)

Label(root, text = 'Agrupar por').grid(row=2,column=0)
Radiobutton(root, text="Centro", variable=agrupacion, value=0).grid(row=2,column=1)
Radiobutton(root, text="TipoCliente", variable=agrupacion, value=1).grid(row=2,column=2)
Radiobutton(root, text="Distrito", variable=agrupacion, value=2).grid(row=2,column=3)


Label(root, text = 'Desglose').grid(row=3,column=0)
Radiobutton(root, text='Mes', variable=tipodesglose, value=1).grid(row=3,column=1)
Radiobutton(root, text='Total anual', variable=tipodesglose, value=0).grid(row=3,column=2)

Checkbutton(root, text='Numero factura', variable=numfactura, onvalue=1, offvalue=0).grid(row=4,column=1)
Checkbutton(root, text='Total ventas',variable=totalventas, onvalue=1, offvalue=0).grid(row=4,column=2)



Button(root, text = 'Salir', command=finalizar).grid(row=5, column=3)


label = Label(root, text='CALCULO DE VENTAS')
label.grid(row=0, column=0)

root.mainloop()